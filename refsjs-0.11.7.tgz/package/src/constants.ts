export const DEMO_DIR = 'demo';

export const SPACE = ' ';
export const NON_BREAKING_SPACE = ' ';
export const DASH = '-';
export const EN_DASH = '–';
export const EM_DASH = '—';
