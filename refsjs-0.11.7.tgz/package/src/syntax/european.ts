import { Syntax } from '../models/syntax';
import { SPACE, NON_BREAKING_SPACE } from '../constants';

export const EUROPEAN: Syntax = {
  name: 'European',
  abbrev: 'euro',
  colon: ',',
  formatColon: ',' + NON_BREAKING_SPACE,
  matchColons: ':,',
  comma: '.',
  formatComma: '.' + SPACE,
  matchCommas: '.',
  dash: '-',
  formatDash: '–',
  matchDashes: '–-',
  semicolon: ';',
  formatSemicolon: NON_BREAKING_SPACE + ';' + SPACE,
  matchSemicolons: ';',
};
