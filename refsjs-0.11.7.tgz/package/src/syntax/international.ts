import { Syntax } from '../models/syntax';
import { SPACE } from '../constants';

export const INTERNATIONAL: Syntax = {
  name: 'International',
  abbrev: 'intl',
  colon: ':',
  formatColon: ':',
  matchColons: ':.',
  comma: ',',
  formatComma: ',' + SPACE,
  matchCommas: ',',
  dash: '-',
  formatDash: '–',
  matchDashes: '–-',
  semicolon: ';',
  formatSemicolon: ';' + SPACE,
  matchSemicolons: ';',
};
