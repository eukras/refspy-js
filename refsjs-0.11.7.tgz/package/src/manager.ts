import { Book } from './models/book';
import { Library } from './models/library';
import { Language } from './models/language';
import { mergeRanges, combineRanges, range } from './models/range';
import {
  Reference,
  reference,
  bookReference as bookRef,
  chapterReference as chapterRef,
  verseReference as verseRef,
} from './models/reference';
import { Syntax } from './models/syntax';
import { verse } from './models/verse';
import { Number, makeNumber } from './types/number';
import { Formatter } from './formatter';
import { indexBookAliases, indexBooks, indexLibraries, BookKey, BookIdPair, bookKey } from './indexers';
import { Matcher } from './matcher';
import { Navigator } from './navigator';
import { urlParam, urlEscape, sequentialReplace } from './utils';

// Collation return types
export type BookCollation = [Book, Reference[]];
export type LibraryCollation = [Library, BookCollation[]];
export type ChapterEntry = [Number, Reference[]];
export type BookChapterCollation = [Book, ChapterEntry[]];
export type LibraryChapterCollation = [Library, BookChapterCollation[]];
export type VerseEntry = [string, Reference[]];
export type ChapterVerseCollation = [Number, VerseEntry[]];
export type BookVerseCollation = [Book, ChapterVerseCollation[]];
export type LibraryVerseCollation = [Library, BookVerseCollation[]];

export class Manager {
  libraries: Map<Number, Library>;
  books: Map<BookKey, Book>;
  bookAliases: Map<string, BookIdPair>;
  language: Language;
  syntax: Syntax;
  matcher: Matcher;
  formatter: Formatter;
  navigator: Navigator;

  constructor(
    libraries: Library[],
    language: Language,
    syntax?: Syntax,
    includeTwoLetterAliases = true,
  ) {
    this.libraries = indexLibraries(libraries);
    this.books = indexBooks(libraries);
    this.bookAliases = indexBookAliases(libraries, includeTwoLetterAliases);
    this.language = language;
    this.syntax = syntax ?? language.syntax;
    this.matcher = new Matcher(this.books, this.bookAliases, this.language, this.syntax);
    this.formatter = new Formatter(this.books, this.bookAliases);
    this.navigator = new Navigator(this.books, this.bookAliases);
  }

  // --- Index and summary ---

  makeIndexReferences(references: Reference[]): Reference[] {
    const filtered = references
      .filter(ref => ref && !ref.isBook())
      .sort((a, b) => (a.lt(b) ? -1 : b.lt(a) ? 1 : 0));
    const index: Reference[] = [];
    for (const [, bookCollation] of this.collate(filtered)) {
      for (const [, refList] of bookCollation) {
        index.push(this.sortReferences(refList));
      }
    }
    return index;
  }

  makeIndex(references: Reference[], pattern?: string): string | null {
    const indexes = this.makeIndexReferences(references);
    return indexes.length > 0
      ? indexes.map(ref => this.template(ref, pattern)).join(', ')
      : null;
  }

  makeSummaryReferences(references: Reference[]): Reference[] {
    const filtered = references
      .filter(ref => ref && !ref.isBook())
      .sort((a, b) => (a.lt(b) ? -1 : b.lt(a) ? 1 : 0));
    const summary: Reference[] = [];
    for (const [, bookCollation] of this.collate(filtered)) {
      for (const [, refList] of bookCollation) {
        summary.push(this.combineReferences(refList));
      }
    }
    return summary;
  }

  makeSummary(references: Reference[], pattern?: string): string | null {
    const summaries = this.makeSummaryReferences(references);
    return summaries.length > 0
      ? summaries.map(ref => this.template(ref, pattern)).join(', ')
      : null;
  }

  makeSummaryReferencesByChapter(references: Reference[]): Reference[] {
    const filtered = references
      .filter(ref => ref && !ref.isBook())
      .sort((a, b) => (a.lt(b) ? -1 : b.lt(a) ? 1 : 0));
    const summary: Reference[] = [];
    for (const [, bookCollation] of this.collateChapterReferences(filtered)) {
      for (const [, chapterCollation] of bookCollation) {
        for (const [, refList] of chapterCollation) {
          summary.push(this.combineReferences(refList));
        }
      }
    }
    return summary;
  }

  makeSummaryByChapter(references: Reference[], pattern?: string): string | null {
    const summaries = this.makeSummaryReferencesByChapter(references);
    return summaries.length > 0
      ? summaries.map(ref => this.template(ref, pattern)).join(', ')
      : null;
  }

  makeHotspotTuples(
    references: Reference[],
    maxChapters = 7,
    minReferences = 2,
  ): [Reference, number][] {
    if (references.length === 0) return [];
    const totals = new Map<string, number>();
    for (const r of this.sortReferences(references).ranges) {
      for (const key of [
        `${r.start.library}:${r.start.book}:${r.start.chapter}`,
        `${r.end.library}:${r.end.book}:${r.end.chapter}`,
      ]) {
        totals.set(key, (totals.get(key) ?? 0) + 1);
      }
    }
    const hotspots: [Reference, number][] = [];
    for (const [key, total] of totals.entries()) {
      if (total / 2 >= minReferences) {
        const [libStr, bookStr, chapStr] = key.split(':');
        const chapRefObj = chapterRef(
          makeNumber(parseInt(libStr, 10)),
          makeNumber(parseInt(bookStr, 10)),
          makeNumber(parseInt(chapStr, 10)),
        );
        hotspots.push([chapRefObj, Math.floor(total / 2)]);
      }
    }
    return hotspots.sort(([, a], [, b]) => b - a).slice(0, maxChapters);
  }

  makeHotspotReferences(
    references: Reference[],
    maxChapters = 7,
    minReferences = 2,
  ): Reference[] {
    return this.makeHotspotTuples(references, maxChapters, minReferences).map(([ref]) => ref);
  }

  makeHotspots(
    references: Reference[],
    maxChapters = 7,
    minReferences = 2,
    pattern?: string,
  ): string | null {
    const refs = this.makeHotspotReferences(references, maxChapters, minReferences);
    return refs.length > 0
      ? refs.map(ref => this.template(ref, pattern)).join(', ')
      : null;
  }

  // --- Merging ---

  sortReferences(references: Reference[]): Reference {
    const ranges = references.flatMap(ref => ref.ranges);
    return reference(...ranges.sort((a, b) => (a.lt(b) ? -1 : b.lt(a) ? 1 : 0)));
  }

  mergeReferences(references: Reference[]): Reference {
    const ranges = references.flatMap(ref => ref.ranges);
    return reference(...mergeRanges(ranges));
  }

  combineReferences(references: Reference[]): Reference {
    const ranges = references.flatMap(ref => ref.ranges);
    return reference(...combineRanges(ranges));
  }

  // --- Collation ---

  collate(references: Reference[]): LibraryCollation[] {
    return this.collateBookReferences(references);
  }

  collateBookReferences(references: Reference[]): LibraryCollation[] {
    const libraryList: LibraryCollation[] = [];
    for (const [libraryId, booksMap] of this.collateByBook(references).entries()) {
      const bookList: BookCollation[] = [];
      for (const [bookId, refs] of booksMap.entries()) {
        bookList.push([this.books.get(bookKey(libraryId, bookId))!, refs]);
      }
      libraryList.push([this.libraries.get(libraryId)!, bookList]);
    }
    return libraryList;
  }

  collateByBook(references: Reference[]): Map<Number, Map<Number, Reference[]>> {
    const collation = new Map<Number, Map<Number, Reference[]>>();
    for (const ref of references.filter(r => r.countBooks() === 1)) {
      const v1 = ref.ranges[0].start;
      if (!collation.has(v1.library)) collation.set(v1.library, new Map());
      const libMap = collation.get(v1.library)!;
      if (!libMap.has(v1.book)) libMap.set(v1.book, []);
      libMap.get(v1.book)!.push(ref);
    }
    return collation;
  }

  collateChapterReferences(references: Reference[]): LibraryChapterCollation[] {
    const libraryList: LibraryChapterCollation[] = [];
    for (const [libraryId, booksMap] of this.collateByChapter(references).entries()) {
      const bookList: BookChapterCollation[] = [];
      for (const [bookId, chaptersMap] of booksMap.entries()) {
        const chapterList: ChapterEntry[] = [];
        for (const [chapterId, refs] of chaptersMap.entries()) {
          chapterList.push([chapterId, refs]);
        }
        bookList.push([this.books.get(bookKey(libraryId, bookId))!, chapterList]);
      }
      libraryList.push([this.libraries.get(libraryId)!, bookList]);
    }
    return libraryList;
  }

  collateByChapter(
    references: Reference[],
  ): Map<Number, Map<Number, Map<Number, Reference[]>>> {
    const collation = new Map<Number, Map<Number, Map<Number, Reference[]>>>();
    for (const ref of references.filter(r => r.countBooks() === 1)) {
      const v1 = ref.ranges[0].start;
      if (!collation.has(v1.library)) collation.set(v1.library, new Map());
      const libMap = collation.get(v1.library)!;
      if (!libMap.has(v1.book)) libMap.set(v1.book, new Map());
      const bookMap = libMap.get(v1.book)!;
      if (!bookMap.has(v1.chapter)) bookMap.set(v1.chapter, []);
      bookMap.get(v1.chapter)!.push(ref);
    }
    return collation;
  }

  collateVerseReferences(references: Reference[]): LibraryVerseCollation[] {
    const libraryList: LibraryVerseCollation[] = [];
    for (const [libraryId, booksMap] of this.collateByVerse(references).entries()) {
      const bookList: BookVerseCollation[] = [];
      for (const [bookId, chaptersMap] of booksMap.entries()) {
        const chapterList: ChapterVerseCollation[] = [];
        for (const [chapterId, versesMap] of chaptersMap.entries()) {
          const verseList: VerseEntry[] = [];
          for (const [refNumbers, refs] of versesMap.entries()) {
            verseList.push([refNumbers, refs]);
          }
          chapterList.push([chapterId, verseList]);
        }
        bookList.push([this.books.get(bookKey(libraryId, bookId))!, chapterList]);
      }
      libraryList.push([this.libraries.get(libraryId)!, bookList]);
    }
    return libraryList;
  }

  collateByVerse(
    references: Reference[],
  ): Map<Number, Map<Number, Map<Number, Map<string, Reference[]>>>> {
    const collation = new Map<Number, Map<Number, Map<Number, Map<string, Reference[]>>>>();
    for (const ref of references.filter(r => r.countBooks() === 1)) {
      const v1 = ref.ranges[0].start;
      if (!collation.has(v1.library)) collation.set(v1.library, new Map());
      const libMap = collation.get(v1.library)!;
      if (!libMap.has(v1.book)) libMap.set(v1.book, new Map());
      const bookMap = libMap.get(v1.book)!;
      if (!bookMap.has(v1.chapter)) bookMap.set(v1.chapter, new Map());
      const chapMap = bookMap.get(v1.chapter)!;
      const refNumbers = this.numbers(ref);
      if (!chapMap.has(refNumbers)) chapMap.set(refNumbers, []);
      chapMap.get(refNumbers)!.push(ref);
    }
    return collation;
  }

  // --- Matching ---

  firstReference(text: string): [string | null, Reference | null] {
    const result = this.matcher.generateReferences(text).next();
    return result.done ? [null, null] : result.value;
  }

  findReferences(
    text: string,
    includeBooks = false,
    includeNones = false,
    useContext = true,
  ): [string, Reference | null][] {
    return [...this.matcher.generateReferences(text, includeBooks, includeNones, useContext)];
  }

  *generateReferences(
    text: string,
    yieldBooks = false,
    yieldNones = false,
    useContext = true,
  ): Generator<[string, Reference | null]> {
    yield* this.matcher.generateReferences(text, yieldBooks, yieldNones, useContext);
  }

  // --- Search and replace

  sequentialReplace(
    text: string,
    find: string[],
    replace: string[],
  ): string {
    return sequentialReplace(text, find, replace);
  }

  // --- Reference creators ---

  bcv(alias: string, c?: Number, v?: Number, vEnd?: Number): Reference {
    if (!this.bookAliases.has(alias)) {
      throw new Error(`Book alias "${alias}" not found.`);
    }
    const [libraryId, bookId] = this.bookAliases.get(alias)!;
    if (c === undefined) return bookRef(libraryId, bookId);
    if (v === undefined) return chapterRef(libraryId, bookId, c);
    if (vEnd === undefined) return verseRef(libraryId, bookId, c, v);
    return reference(range(
      verse(libraryId, bookId, c, v),
      verse(libraryId, bookId, c, vEnd),
    ));
  }

  bcr(alias: string, c: Number, vRanges: (Number | [Number, Number])[]): Reference {
    if (!this.bookAliases.has(alias)) {
      throw new Error(`Book alias "${alias}" not found.`);
    }
    const [libraryId, bookId] = this.bookAliases.get(alias)!;
    const ranges = vRanges.map(val => {
      if (Array.isArray(val)) {
        const [vStart, vEnd] = val;
        return range(verse(libraryId, bookId, c, vStart), verse(libraryId, bookId, c, vEnd));
      }
      return range(verse(libraryId, bookId, c, val), verse(libraryId, bookId, c, val));
    });
    return reference(...ranges);
  }

  r(text: string): Reference | null {
    const [, ref] = this.firstReference(text);
    return ref;
  }

  // --- Navigation ---

  nextChapter(ref: Reference): Reference | null {
    return this.navigator.nextChapter(ref);
  }

  prevChapter(ref: Reference): Reference | null {
    return this.navigator.prevChapter(ref);
  }

  // --- Manipulation ---

  getBook(ref: Reference): Book {
    const v1 = ref.ranges[0].start;
    return this.books.get(bookKey(v1.library, v1.book))!;
  }

  bookReference(ref: Reference): Reference {
    const v1 = ref.ranges[0].start;
    return reference(range(
      verse(v1.library, v1.book, makeNumber(1), makeNumber(1)),
      verse(v1.library, v1.book, makeNumber(999), makeNumber(999)),
    ));
  }

  chapterReference(ref: Reference): Reference {
    const v1 = ref.ranges[0].start;
    return reference(range(
      verse(v1.library, v1.book, v1.chapter, makeNumber(1)),
      verse(v1.library, v1.book, v1.chapter, makeNumber(999)),
    ));
  }

  // --- Formatting ---

  link(ref: Reference): string {
    return this.formatter.format(ref, this.formatter.linkFormat());
  }

  name(ref: Reference): string {
    return this.formatter.format(ref, this.formatter.nameFormat(this.language));
  }

  book(ref: Reference): string {
    return this.formatter.format(ref, this.formatter.bookFormat(this.language));
  }

  abbrevName(ref: Reference): string {
    return this.formatter.format(ref, this.formatter.abbrevNameFormat(this.language));
  }

  abbrevBook(ref: Reference): string {
    return this.formatter.format(ref, this.formatter.abbrevBookFormat(this.language));
  }

  numbers(ref: Reference): string {
    return this.formatter.format(ref, this.formatter.numberFormat(this.language));
  }

  abbrevNumbers(ref: Reference): string {
    return this.formatter.format(ref, this.formatter.abbrevNumberFormat(this.language));
  }

  // --- Template formatting ---

  template(ref: Reference | null, pattern?: string): string {
    if (ref === null) return '';
    let out = pattern ?? '{ABBREV_NAME}';
    const tokens = [...out.matchAll(/\{[A-Z_]+\}/g)].map(m => m[0]);
    const nums = this.numbers(ref);
    for (const token of tokens) {
      switch (token) {
        case '{LINK}':
          out = out.replace('{LINK}', urlEscape(this.link(ref)));
          break;
        case '{NAME}':
          out = out.replace('{NAME}', this.name(ref));
          break;
        case '{BOOK}':
          out = out.replace('{BOOK}', this.book(ref));
          break;
        case '{NUMBERS}':
          out = out.replace('{NUMBERS}', nums);
          break;
        case '{ASCII_NUMBERS}':
          out = out.replace('{ASCII_NUMBERS}', nums.replace(/–/g, '-'));
          break;
        case '{ABBREV_NAME}':
          out = out.replace('{ABBREV_NAME}', this.abbrevName(ref));
          break;
        case '{ABBREV_BOOK}':
          out = out.replace('{ABBREV_BOOK}', this.abbrevBook(ref));
          break;
        case '{ESC_NAME}':
          out = out.replace('{ESC_NAME}', urlEscape(this.name(ref)));
          break;
        case '{ESC_BOOK}':
          out = out.replace('{ESC_BOOK}', urlEscape(this.book(ref)));
          break;
        case '{ESC_NUMBERS}':
          out = out.replace('{ESC_NUMBERS}', urlEscape(nums));
          break;
        case '{ESC_ASCII_NUMBERS}':
          out = out.replace('{ESC_ASCII_NUMBERS}', urlEscape(nums.replace(/–/g, '-')));
          break;
        case '{ESC_ABBREV_NAME}':
          out = out.replace('{ESC_ABBREV_NAME}', urlEscape(this.abbrevName(ref)));
          break;
        case '{ESC_ABBREV_BOOK}':
          out = out.replace('{ESC_ABBREV_BOOK}', urlEscape(this.abbrevBook(ref)));
          break;
        case '{PARAM_NAME}':
          out = out.replace('{PARAM_NAME}', urlParam(this.name(ref)));
          break;
        case '{PARAM_BOOK}':
          out = out.replace('{PARAM_BOOK}', urlParam(this.book(ref)));
          break;
        case '{PARAM_NUMBERS}':
          out = out.replace('{PARAM_NUMBERS}', urlParam(nums));
          break;
      }
    }
    return out;
  }
}
