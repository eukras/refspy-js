import { Number } from '../types/number';

export interface Book {
  id: Number;
  name: string;
  abbrev: string;
  aliases: string[];
  chapters: number;
}
