import { Number, makeNumber } from '../types/number';
import { Book } from './book';

export const OT_ID: Number = makeNumber(200);
export const DC_ID: Number = makeNumber(210);
export const DCO_ID: Number = makeNumber(220);
export const NT_ID: Number = makeNumber(400);

export interface Library {
  id: Number;
  name: string;
  abbrev: string;
  books: Book[];
}
