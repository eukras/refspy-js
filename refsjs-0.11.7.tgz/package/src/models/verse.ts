import { Number, makeNumber } from '../types/number';
import { Index } from '../types/index';

export type VerseTuple = [Number, Number, Number, Number];

export class Verse {
  constructor(
    readonly library: Number,
    readonly book: Number,
    readonly chapter: Number,
    readonly verse: Number,
  ) {}

  toTuple(): VerseTuple {
    return [this.library, this.book, this.chapter, this.verse];
  }

  lt(other: Verse): boolean {
    return compareTuples(this.toTuple(), other.toTuple()) < 0;
  }

  lte(other: Verse): boolean {
    return compareTuples(this.toTuple(), other.toTuple()) <= 0;
  }

  gt(other: Verse): boolean {
    return compareTuples(this.toTuple(), other.toTuple()) > 0;
  }

  gte(other: Verse): boolean {
    return compareTuples(this.toTuple(), other.toTuple()) >= 0;
  }

  equals(other: Verse): boolean {
    const [l, b, c, v] = this.toTuple();
    const [l2, b2, c2, v2] = other.toTuple();
    return l === l2 && b === b2 && c === c2 && v === v2;
  }

  static fromIndex(index: Index): Verse {
    const v = index % 1000;
    const lbc = Math.floor(index / 1000);
    const c = lbc % 1000;
    const lb = Math.floor(lbc / 1000);
    const b = lb % 1000;
    const l = Math.floor(lb / 1000);
    return new Verse(makeNumber(l), makeNumber(b), makeNumber(c), makeNumber(v));
  }

  index(): Index {
    return ((this.library * 1000 + this.book) * 1000 + this.chapter) * 1000 + this.verse;
  }
}

function compareTuples(a: VerseTuple, b: VerseTuple): number {
  for (let i = 0; i < 4; i++) {
    if (a[i] < b[i]) return -1;
    if (a[i] > b[i]) return 1;
  }
  return 0;
}

export function verse(library: Number, book: Number, chapter: Number, v: Number): Verse {
  return new Verse(library, book, chapter, v);
}
