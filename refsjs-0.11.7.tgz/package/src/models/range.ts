import { Number, makeNumber } from '../types/number';
import { Verse, verse } from './verse';

export class Range {
  constructor(
    readonly start: Verse,
    readonly end: Verse,
  ) {
    if (!start.lte(end)) {
      throw new Error(`Range start must be <= end`);
    }
  }

  toTuple(): [Verse, Verse] {
    return [this.start, this.end];
  }

  lt(other: Range): boolean {
    if (this.start.lt(other.start)) return true;
    if (other.start.lt(this.start)) return false;
    return this.end.lt(other.end);
  }

  overlaps(other: Range): boolean {
    return (
      (other.start.lte(this.start) && this.start.lte(other.end)) ||
      (other.start.lte(this.end) && this.end.lte(other.end)) ||
      (this.start.lte(other.start) && other.start.lte(this.end)) ||
      (this.start.lte(other.end) && other.end.lte(this.end))
    );
  }

  contains(other: Range): boolean {
    return this.start.lte(other.start) && this.end.gte(other.end);
  }

  adjoins(other: Range): boolean {
    if (
      (this.isVerse() || this.isVerseRange() || this.isInterChapterRange()) &&
      (other.isVerse() || other.isVerseRange() || other.isInterChapterRange())
    ) {
      return (
        (other.start.gt(this.start) && other.start.verse === this.end.verse + 1) ||
        (this.start.gt(other.start) && this.start.verse === other.end.verse + 1)
      );
    } else if (
      this.sameBookAs(other) &&
      (this.isChapter() || this.isChapterRange()) &&
      (other.isChapter() || other.isChapterRange())
    ) {
      return (
        (other.start.gt(this.start) && other.start.chapter === this.end.chapter + 1) ||
        (this.start.gt(other.start) && this.start.chapter === other.end.chapter + 1)
      );
    } else if (
      this.sameLibraryAs(other) &&
      (this.isBook() || this.isBookRange()) &&
      (other.isBook() || other.isBookRange())
    ) {
      return (
        (other.start.gt(this.start) && other.start.book === this.end.book + 1) ||
        (this.start.gt(other.start) && this.start.book === other.end.book + 1)
      );
    }
    return false;
  }

  merge(other: Range): Range {
    const startA: [number, number] = [this.start.chapter, this.start.verse];
    const startB: [number, number] = [other.start.chapter, other.start.verse];
    const [minStartC, minStartV] = comparePair(startA, startB) <= 0 ? startA : startB;

    const endA: [number, number] = [this.end.chapter, this.end.verse];
    const endB: [number, number] = [other.end.chapter, other.end.verse];
    const [maxEndC, maxEndV] = comparePair(endA, endB) >= 0 ? endA : endB;

    return new Range(
      verse(
        makeNumber(Math.min(this.start.library, other.start.library)),
        makeNumber(Math.min(this.start.book, other.start.book)),
        makeNumber(minStartC),
        makeNumber(minStartV),
      ),
      verse(
        makeNumber(Math.max(this.end.library, other.end.library)),
        makeNumber(Math.max(this.end.book, other.end.book)),
        makeNumber(maxEndC),
        makeNumber(maxEndV),
      ),
    );
  }

  join(other: Range): Range {
    if (this.start.lt(other.start)) {
      return new Range(this.start, other.end);
    } else {
      return new Range(other.start, this.end);
    }
  }

  isSameLibrary(): boolean {
    return this.start.library === this.end.library;
  }

  sameLibraryAs(other: Range): boolean {
    const ids = new Set([
      this.start.library,
      this.end.library,
      other.start.library,
      other.end.library,
    ]);
    return ids.size === 1;
  }

  isSameBook(): boolean {
    return this.isSameLibrary() && this.start.book === this.end.book;
  }

  sameBookAs(other: Range): boolean {
    const ids = new Set([
      this.start.book,
      this.end.book,
      other.start.book,
      other.end.book,
    ]);
    return this.sameLibraryAs(other) && ids.size === 1;
  }

  isSameChapter(): boolean {
    return (
      this.isSameLibrary() &&
      this.isSameBook() &&
      this.start.chapter === this.end.chapter
    );
  }

  sameChapterAs(other: Range): boolean {
    const ids = new Set([
      this.start.chapter,
      this.end.chapter,
      other.start.chapter,
      other.end.chapter,
    ]);
    return this.sameBookAs(other) && ids.size === 1;
  }

  isBook(): boolean {
    return (
      this.start.library === this.end.library &&
      this.start.book === this.end.book &&
      this.start.chapter === 1 &&
      this.end.chapter === 999 &&
      this.start.verse === 1 &&
      this.end.verse === 999
    );
  }

  isBookRange(): boolean {
    return (
      this.start.library === this.end.library &&
      this.start.book !== this.end.book &&
      this.start.chapter === 1 &&
      this.end.chapter === 999 &&
      this.start.verse === 1 &&
      this.end.verse === 999
    );
  }

  isInterBookRange(): boolean {
    return (
      this.start.library === this.end.library &&
      this.start.book !== this.end.book &&
      (this.start.chapter !== 1 || this.end.chapter !== 999)
    );
  }

  isChapter(): boolean {
    return (
      this.start.library === this.end.library &&
      this.start.book === this.end.book &&
      this.start.chapter === this.end.chapter &&
      this.start.verse === 1 &&
      this.end.verse === 999
    );
  }

  isChapterRange(): boolean {
    return (
      this.start.library === this.end.library &&
      this.start.book === this.end.book &&
      this.start.chapter !== this.end.chapter &&
      this.start.verse === 1 &&
      this.end.verse === 999
    );
  }

  isInterChapterRange(): boolean {
    return (
      this.start.library === this.end.library &&
      this.start.book === this.end.book &&
      this.start.chapter !== this.end.chapter &&
      !(this.start.verse === 1 && this.end.verse === 999)
    );
  }

  isVerse(): boolean {
    return (
      this.start.library === this.end.library &&
      this.start.book === this.end.book &&
      this.start.chapter === this.end.chapter &&
      this.start.verse === this.end.verse
    );
  }

  isVerseRange(): boolean {
    return (
      this.start.library === this.end.library &&
      this.start.book === this.end.book &&
      this.start.chapter === this.end.chapter &&
      this.start.verse !== this.end.verse
    );
  }
}

function comparePair(a: [number, number], b: [number, number]): number {
  if (a[0] !== b[0]) return a[0] - b[0];
  return a[1] - b[1];
}

function sortRanges(ranges: Range[]): Range[] {
  return [...ranges].sort((a, b) => (a.lt(b) ? -1 : b.lt(a) ? 1 : 0));
}

export function minRange(ranges: Range[]): Range {
  return ranges.reduce((a, b) => (a.lt(b) ? a : b));
}

export function maxRange(ranges: Range[]): Range {
  return ranges.reduce((a, b) => (b.lt(a) ? a : b));
}

export function range(start: Verse, end: Verse): Range {
  return new Range(start, end);
}

export function mergeRanges(ranges: Range[], skipSort = false): Range[] {
  if (ranges.length === 0) return [];
  const sorted = skipSort ? [...ranges] : sortRanges(ranges);
  const result: Range[] = [];
  let last = sorted[0];
  for (const current of sorted.slice(1)) {
    if (last.overlaps(current)) {
      last = last.merge(current);
    } else {
      result.push(last);
      last = current;
    }
  }
  result.push(last);
  return result;
}

export function combineRanges(ranges: Range[], skipMerge = false): Range[] {
  if (ranges.length === 0) return [];
  const merged = skipMerge ? ranges : mergeRanges(ranges);
  const result: Range[] = [];
  let last = merged[0];
  for (const current of merged.slice(1)) {
    if (last.adjoins(current)) {
      last = last.join(current);
    } else {
      result.push(last);
      last = current;
    }
  }
  result.push(last);
  return result;
}

export function bookRange(
  libraryId: Number,
  bookId: Number,
  bookEndId?: Number,
): Range {
  return range(
    verse(libraryId, bookId, makeNumber(1), makeNumber(1)),
    verse(libraryId, bookEndId ?? bookId, makeNumber(999), makeNumber(999)),
  );
}

export function chapterRange(
  libraryId: Number,
  bookId: Number,
  chapterId: Number,
  chapterEndId?: Number,
): Range {
  return range(
    verse(libraryId, bookId, chapterId, makeNumber(1)),
    verse(libraryId, bookId, chapterEndId ?? chapterId, makeNumber(999)),
  );
}

export function verseRange(
  libraryId: Number,
  bookId: Number,
  chapterId: Number,
  verseId: Number,
  verseEndId?: Number,
): Range {
  return range(
    verse(libraryId, bookId, chapterId, verseId),
    verse(libraryId, bookId, chapterId, verseEndId ?? verseId),
  );
}
