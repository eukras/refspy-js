import { Number, makeNumber } from '../types/number';
import { Range, mergeRanges, combineRanges, range as _range, minRange, maxRange } from './range';
import { Verse, verse } from './verse';

export class Reference {
  readonly ranges: Range[];

  constructor(ranges: Range[]) {
    if (ranges.length === 0) {
      throw new Error('Reference must contain at least one Range');
    }
    this.ranges = ranges;
  }

  add(other: Reference): Reference {
    return new Reference([...this.ranges, ...other.ranges]);
  }

  lt(other: Reference): boolean {
    const common = Math.min(this.ranges.length, other.ranges.length);
    for (let i = 0; i < common; i++) {
      if (!this.ranges[i].start.equals(other.ranges[i].start)) {
        return this.ranges[i].start.lt(other.ranges[i].start);
      }
      if (!this.ranges[i].end.equals(other.ranges[i].end)) {
        return this.ranges[i].end.lt(other.ranges[i].end);
      }
    }
    return false;
  }

  equals(other: Reference): boolean {
    if (this.ranges.length !== other.ranges.length) return false;
    return this.ranges.every((r, i) => {
      const o = other.ranges[i];
      return r.start.equals(o.start) && r.end.equals(o.end);
    });
  }

  overlaps(other: Reference): boolean {
    return this.ranges.some(selfRange =>
      other.ranges.some(otherRange => selfRange.overlaps(otherRange)),
    );
  }

  contains(other: Reference): boolean {
    return other.ranges.every(otherRange =>
      this.ranges.some(selfRange => selfRange.contains(otherRange)),
    );
  }

  adjoins(other: Reference): boolean {
    return (
      maxRange(this.ranges).adjoins(minRange(other.ranges)) ||
      minRange(this.ranges).adjoins(maxRange(other.ranges))
    );
  }

  countBooks(): number {
    const libraryBooks = new Set<string>();
    for (const r of this.ranges) {
      libraryBooks.add(`${r.start.library}:${r.start.book}`);
      libraryBooks.add(`${r.end.library}:${r.end.book}`);
    }
    return libraryBooks.size;
  }

  isBook(): boolean {
    return this.ranges[0].isBook();
  }

  isChapter(): boolean {
    return this.ranges[0].isChapter();
  }

  firstVerse(): Verse {
    return this.ranges[0].start;
  }

  lastVerse(): Verse {
    return this.ranges[this.ranges.length - 1].end;
  }

  lastRange(): Range {
    return this.ranges[this.ranges.length - 1];
  }

  sort(): Reference {
    return new Reference([...this.ranges].sort((a, b) => (a.lt(b) ? -1 : b.lt(a) ? 1 : 0)));
  }

  merge(): Reference {
    return new Reference(mergeRanges(this.ranges));
  }

  combine(): Reference {
    return new Reference(combineRanges(this.ranges));
  }
}

export function reference(...ranges: Range[]): Reference {
  return new Reference(ranges);
}

export function bookReference(libraryId: Number, bookId: Number): Reference {
  return reference(
    _range(
      verse(libraryId, bookId, makeNumber(1), makeNumber(1)),
      verse(libraryId, bookId, makeNumber(999), makeNumber(999)),
    ),
  );
}

export function chapterReference(
  libraryId: Number,
  bookId: Number,
  chapterId: Number,
): Reference {
  return reference(
    _range(
      verse(libraryId, bookId, chapterId, makeNumber(1)),
      verse(libraryId, bookId, chapterId, makeNumber(999)),
    ),
  );
}

export function verseReference(
  libraryId: Number,
  bookId: Number,
  chapterId: Number,
  verseId: Number,
  verseEndId?: Number,
): Reference {
  return reference(
    _range(
      verse(libraryId, bookId, chapterId, verseId),
      verse(libraryId, bookId, chapterId, verseEndId ?? verseId),
    ),
  );
}

