import { Syntax } from './syntax';

export interface Language {
  verseMarkers: string[];
  ambiguousAliases: string[];
  numberPrefixes: Record<string, string[]>;
  syntax: Syntax;
  defaultLinkPattern: string;
  demonstrationText: string;
  ntTranslation: string;
  otTranslation: string;
  dcTranslation: string;
  dcNotes: string[];
}
