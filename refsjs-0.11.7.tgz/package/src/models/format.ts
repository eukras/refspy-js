export interface Format {
  colon: string;
  comma: string;
  dash: string;
  semicolon: string;
  bookOnly: boolean;
  numberOnly: boolean;
  property: string | null;
}
