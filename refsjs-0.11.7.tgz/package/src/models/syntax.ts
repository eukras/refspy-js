export interface Syntax {
  name: string;
  abbrev: string;
  colon: string;
  comma: string;
  dash: string;
  semicolon: string;
  formatColon: string;
  formatComma: string;
  formatDash: string;
  formatSemicolon: string;
  matchColons: string;
  matchCommas: string;
  matchDashes: string;
  matchSemicolons: string;
}

export function syntaxLabel(syntax: Syntax): string {
  const bracket = (chars: string) => (chars.length > 1 ? `[${chars}]` : chars);
  return [
    'c', bracket(syntax.matchColons),
    'v', bracket(syntax.matchCommas),
    'v', syntax.dash,
    'v', bracket(syntax.matchSemicolons),
    ' (', syntax.abbrev, ')',
  ].join('');
}
