import { LANGUAGES, LIBRARIES, SYNTAX } from './config';
import { Manager } from './manager';
import { Language } from './models/language';
import { Library } from './models/library';
import { Syntax } from './models/syntax';

export function getCanon(canonName: string, localeName: string): Library[] {
  if (canonName in LIBRARIES && localeName in LIBRARIES[canonName]) {
    return LIBRARIES[canonName][localeName];
  }
  throw new Error(`Canon '${canonName}' not found for locale '${localeName}'.`);
}

export function getLanguage(languageName: string): Language {
  if (languageName in LANGUAGES) return LANGUAGES[languageName];
  throw new Error(`Language '${languageName}' not found.`);
}

export function getSyntax(syntaxName: string): Syntax {
  if (syntaxName in SYNTAX) return SYNTAX[syntaxName];
  throw new Error(`Syntax '${syntaxName}' not found.`);
}

export function refspy(
  canonName = 'protestant',
  localeName = 'en_US',
  syntaxName?: string,
  includeTwoLetterAliases = true,
): Manager {
  return new Manager(
    getCanon(canonName, localeName),
    getLanguage(localeName.slice(0, 2)),
    syntaxName !== undefined ? getSyntax(syntaxName) : undefined,
    includeTwoLetterAliases,
  );
}

export { Manager } from './manager';
export { LIBRARIES, LANGUAGES, SYNTAX, LANGUAGE_OPTIONS, SYNTAX_OPTIONS } from './config';
export type { Book } from './models/book';
export type { Library } from './models/library';
export type { Language } from './models/language';
export type { Syntax } from './models/syntax';
export type { Format } from './models/format';
export { Verse, verse } from './models/verse';
export { Range, range, mergeRanges, combineRanges } from './models/range';
export { Reference, reference } from './models/reference';
export { makeNumber } from './types/number';
export type { Number } from './types/number';
