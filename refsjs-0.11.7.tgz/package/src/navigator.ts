import { Book } from './models/book';
import { Number, makeNumber } from './types/number';
import { range } from './models/range';
import { Reference, reference } from './models/reference';
import { verse } from './models/verse';
import { BookKey, BookIdPair } from './indexers';

export class Navigator {
  private books: Map<BookKey, Book>;
  private bookAliases: Map<string, BookIdPair>;

  constructor(books: Map<BookKey, Book>, bookAliases: Map<string, BookIdPair>) {
    this.books = books;
    this.bookAliases = bookAliases;
  }

  prevChapter(ref: Reference): Reference | null {
    const v1 = ref.ranges[0].start;
    if (v1.chapter > 1) {
      const prevChapter = makeNumber(v1.chapter - 1);
      return reference(
        range(
          verse(v1.library, v1.book, prevChapter, makeNumber(1)),
          verse(v1.library, v1.book, prevChapter, makeNumber(999)),
        ),
      );
    } else {
      const prevBook = this.lookupBook(v1.library, v1.book - 1);
      if (!prevBook) return null;
      const endChapter = makeNumber(prevBook.chapters);
      return reference(
        range(
          verse(v1.library, prevBook.id, endChapter, makeNumber(1)),
          verse(v1.library, prevBook.id, endChapter, makeNumber(999)),
        ),
      );
    }
  }

  nextChapter(ref: Reference): Reference | null {
    const v1 = ref.ranges[0].start;
    const currentBook = this.lookupBook(v1.library, v1.book);
    if (!currentBook) return null;
    const endChapter = currentBook.chapters;
    if (v1.chapter < endChapter) {
      const nextChapter = makeNumber(v1.chapter + 1);
      return reference(
        range(
          verse(v1.library, v1.book, nextChapter, makeNumber(1)),
          verse(v1.library, v1.book, nextChapter, makeNumber(999)),
        ),
      );
    } else {
      const nextBook = this.lookupBook(v1.library, v1.book + 1);
      if (!nextBook) return null;
      return reference(
        range(
          verse(v1.library, nextBook.id, makeNumber(1), makeNumber(1)),
          verse(v1.library, nextBook.id, makeNumber(1), makeNumber(999)),
        ),
      );
    }
  }

  private lookupBook(libraryId: Number, bookId: number): Book | undefined {
    return this.books.get(`${libraryId}:${bookId}`);
  }
}
