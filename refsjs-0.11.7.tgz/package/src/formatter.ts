import { Book } from './models/book';
import { Format } from './models/format';
import { Language } from './models/language';
import { Range } from './models/range';
import { Reference } from './models/reference';
import { Verse } from './models/verse';
import { Number } from './types/number';
import { EM_DASH, SPACE } from './constants';
import { stringTogether } from './utils';
import { BookKey, BookIdPair, bookKey } from './indexers';
import { ENGLISH } from './languages/english';

export class Formatter {
  private books: Map<BookKey, Book>;
  private bookAliases: Map<string, BookIdPair>;

  constructor(books: Map<BookKey, Book>, bookAliases: Map<string, BookIdPair>) {
    this.books = books;
    this.bookAliases = bookAliases;
  }

  format(reference: Reference, fmt: Format, ifInvalid = '[INVALID]'): string {
    let out = '';
    let lastVerse: Verse | null = null;
    for (const nextRange of reference.ranges) {
      if (out.length > 0) {
        out += this.makeDivider(nextRange, lastVerse, fmt);
      }
      if (nextRange.isBookRange()) {
        out += this.makeBookRange(nextRange, fmt);
      } else if (nextRange.isInterBookRange()) {
        out += this.makeInterBookRange(nextRange, fmt);
      } else if (nextRange.isBook()) {
        out += this.makeBook(nextRange, fmt);
      } else if (nextRange.isChapterRange()) {
        out += this.makeChapterRange(nextRange, lastVerse, fmt);
      } else if (nextRange.isInterChapterRange()) {
        out += this.makeInterChapterRange(nextRange, lastVerse, fmt);
      } else if (nextRange.isChapter()) {
        out += this.makeChapter(nextRange, lastVerse, fmt);
      } else if (nextRange.isVerseRange()) {
        out += this.makeVerseRange(nextRange, lastVerse, fmt);
      } else if (nextRange.isVerse()) {
        out += this.makeVerse(nextRange, lastVerse, fmt);
      } else {
        out += ifInvalid;
      }
      lastVerse = nextRange.start;
    }
    return out;
  }

  linkFormat(): Format {
    return {
      colon: ENGLISH.syntax.formatColon,
      comma: ENGLISH.syntax.formatComma,
      dash: ENGLISH.syntax.formatDash,
      semicolon: ENGLISH.syntax.formatSemicolon,
      bookOnly: false,
      numberOnly: false,
      property: 'abbrev',
    };
  }

  nameFormat(language: Language): Format {
    return {
      colon: language.syntax.formatColon,
      comma: language.syntax.formatComma,
      dash: language.syntax.formatDash,
      semicolon: language.syntax.formatSemicolon,
      bookOnly: false,
      numberOnly: false,
      property: 'name',
    };
  }

  bookFormat(language: Language): Format {
    return {
      colon: language.syntax.formatColon,
      comma: language.syntax.formatComma,
      dash: language.syntax.formatDash,
      semicolon: language.syntax.formatSemicolon,
      bookOnly: true,
      numberOnly: false,
      property: 'name',
    };
  }

  numberFormat(language: Language): Format {
    return {
      colon: language.syntax.formatColon,
      comma: language.syntax.formatComma,
      dash: language.syntax.formatDash,
      semicolon: language.syntax.formatSemicolon,
      bookOnly: false,
      numberOnly: true,
      property: null,
    };
  }

  abbrevNameFormat(language: Language): Format {
    return {
      colon: language.syntax.formatColon,
      comma: language.syntax.formatComma,
      dash: language.syntax.formatDash,
      semicolon: language.syntax.formatSemicolon,
      bookOnly: false,
      numberOnly: false,
      property: 'abbrev',
    };
  }

  abbrevBookFormat(language: Language): Format {
    return {
      colon: language.syntax.formatColon,
      comma: language.syntax.formatComma,
      dash: language.syntax.formatDash,
      semicolon: language.syntax.formatSemicolon,
      bookOnly: true,
      numberOnly: false,
      property: 'abbrev',
    };
  }

  abbrevNumberFormat(language: Language): Format {
    return {
      colon: language.syntax.formatColon,
      comma: language.syntax.formatComma,
      dash: language.syntax.formatDash,
      semicolon: language.syntax.formatSemicolon,
      bookOnly: false,
      numberOnly: true,
      property: 'abbrev',
    };
  }

  makeDivider(_: Range, last: Verse | null, fmt: Format): string {
    if (last === null) return '';
    if (
      _.start.library !== last.library ||
      _.start.book !== last.book ||
      _.start.chapter !== last.chapter
    ) {
      return fmt.semicolon;
    }
    return fmt.comma;
  }

  makeBookRange(_: Range, fmt: Format): string {
    const startBook = this.lookupBook(_.start.library, _.start.book);
    const endBook = this.lookupBook(_.end.library, _.end.book);
    return stringTogether(bookProp(startBook, fmt.property), EM_DASH, bookProp(endBook, fmt.property));
  }

  makeInterBookRange(_: Range, fmt: Format): string {
    const startBook = this.lookupBook(_.start.library, _.start.book);
    const endBook = this.lookupBook(_.end.library, _.end.book);
    const startNumber =
      _.start.verse === 1 && _.end.verse === 999
        ? stringTogether(_.start.chapter)
        : stringTogether(_.start.chapter, fmt.colon, _.start.verse);
    const endNumber =
      _.start.verse === 1 && _.end.verse === 999
        ? stringTogether(_.end.chapter)
        : stringTogether(_.end.chapter, fmt.colon, _.end.verse);
    return [bookProp(startBook, fmt.property), startNumber, fmt.dash, bookProp(endBook, fmt.property), endNumber].join(SPACE);
  }

  makeBook(_: Range, fmt: Format): string {
    const startBook = this.lookupBook(_.start.library, _.start.book);
    return bookProp(startBook, fmt.property);
  }

  bookNameIfRequired(_: Range, last: Verse | null, fmt: Format): string {
    if (fmt.numberOnly) return '';
    let bookName = '';
    if (last === null) {
      bookName = this.makeBook(_, fmt);
    } else if (_.start.library !== last.library || _.start.book !== last.book) {
      bookName = this.makeBook(_, fmt);
    }
    if (bookName !== '') {
      return fmt.bookOnly ? bookName : bookName + SPACE;
    }
    return '';
  }

  makeChapterRange(_: Range, last: Verse | null, fmt: Format): string {
    return stringTogether(
      this.bookNameIfRequired(_, last, fmt),
      _.start.chapter,
      fmt.dash,
      _.end.chapter,
    );
  }

  makeInterChapterRange(_: Range, last: Verse | null, fmt: Format): string {
    return stringTogether(
      this.bookNameIfRequired(_, last, fmt),
      _.start.chapter,
      fmt.colon,
      _.start.verse,
      fmt.dash,
      _.end.chapter,
      fmt.colon,
      _.end.verse,
    );
  }

  makeChapter(_: Range, last: Verse | null, fmt: Format): string {
    return stringTogether(this.bookNameIfRequired(_, last, fmt), _.start.chapter);
  }

  chapterNumberIfRequired(_: Range, last: Verse | null, fmt: Format): string {
    if (fmt.bookOnly) return '';
    const book = this.lookupBook(_.start.library, _.start.book);
    if (last === null) {
      if (book.chapters > 1) {
        return stringTogether(_.start.chapter, fmt.colon);
      }
    } else if (
      _.start.library !== last.library ||
      _.start.book !== last.book ||
      _.start.chapter !== last.chapter
    ) {
      if (book.chapters > 1) {
        return stringTogether(_.start.chapter, fmt.colon);
      }
    }
    return '';
  }

  makeVerseRange(_: Range, last: Verse | null, fmt: Format): string {
    if (fmt.bookOnly) return '';
    return stringTogether(
      this.bookNameIfRequired(_, last, fmt),
      this.chapterNumberIfRequired(_, last, fmt),
      fmt.bookOnly ? '' : _.start.verse,
      fmt.bookOnly ? '' : fmt.dash,
      fmt.bookOnly ? '' : _.end.verse,
    );
  }

  makeVerse(_: Range, last: Verse | null, fmt: Format): string {
    return stringTogether(
      this.bookNameIfRequired(_, last, fmt),
      this.chapterNumberIfRequired(_, last, fmt),
      fmt.bookOnly ? '' : _.start.verse,
    );
  }

  private lookupBook(libraryId: Number, bookId: Number): Book {
    const book = this.books.get(bookKey(libraryId, bookId));
    if (!book) throw new Error(`Book not found: ${libraryId}:${bookId}`);
    return book;
  }
}

function bookProp(book: Book, property: string | null): string {
  if (property === 'name') return book.name;
  if (property === 'abbrev') return book.abbrev;
  return '';
}
