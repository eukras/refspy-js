import { Book } from './models/book';
import { Library } from './models/library';
import { Number } from './types/number';
import { stripBookNumber } from './utils';

export const PARAM_CHAR_LIMIT = 20;

export type BookKey = string;
export type BookIdPair = [Number, Number];

export function bookKey(libraryId: Number, bookId: Number): BookKey {
  return `${libraryId}:${bookId}`;
}

export function indexLibraries(libraries: Library[]): Map<Number, Library> {
  return new Map(libraries.map(lib => [lib.id, lib]));
}

export function indexBooks(libraries: Library[]): Map<BookKey, Book> {
  const index = new Map<BookKey, Book>();
  for (const library of libraries) {
    for (const book of library.books) {
      index.set(bookKey(library.id, book.id), book);
    }
  }
  return index;
}

export function addUniqueBookAlias(
  index: Map<string, BookIdPair>,
  alias: string,
  libraryId: Number,
  bookId: Number,
  strict: boolean,
): void {
  if (index.has(alias) && strict) {
    throw new Error(`Book alias '${alias}' is not unique.`);
  }
  if (alias === '') {
    throw new Error(`Book alias is '' for (${libraryId},${bookId})`);
  }
  index.set(alias, [libraryId, bookId]);
}

export function indexBookAliases(
  libraries: Library[],
  includeTwoLetterAliases = true,
  strict = true,
): Map<string, BookIdPair> {
  const index = new Map<string, BookIdPair>();
  for (const library of libraries) {
    for (const book of library.books) {
      const aliases: string[] = [book.name];
      if (book.name !== book.abbrev) {
        aliases.push(book.abbrev);
      }
      for (const alias of book.aliases) {
        const lenAlias = stripBookNumber(alias).length;
        if (
          (lenAlias > 2 && lenAlias < PARAM_CHAR_LIMIT) ||
          (includeTwoLetterAliases && lenAlias === 2)
        ) {
          aliases.push(alias);
        }
      }
      for (const alias of aliases) {
        addUniqueBookAlias(index, alias, library.id, book.id, strict);
      }
    }
  }
  return index;
}
