/**
 * Library, book, chapter, and verse numbers are integers in the range 1 to 999.
 */

declare const __numberBrand: unique symbol;
export type Number = number & { readonly [__numberBrand]: 'Number' };

export function makeNumber(n: number): Number {
  if (!Number.isInteger(n) || n < 1 || n > 999) {
    throw new RangeError(`Number must be an integer between 1 and 999, got ${n}`);
  }
  return n as Number;
}

export function isNumber(n: unknown): n is Number {
  return typeof n === 'number' && Number.isInteger(n) && n >= 1 && n <= 999;
}
