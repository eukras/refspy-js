/**
 * An index number stores a verse in a database using an UNSIGNED INT(12) field.
 *
 * Created by multiplying each constituent number (library, book, chapter, verse)
 * by powers of 1000.
 *
 * Example: verse(1, 2, 3, 4) becomes 1002003004
 */

export type Index = number;
