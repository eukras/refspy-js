import { Book } from './models/book';
import { Language } from './models/language';
import { Range, range, verseRange } from './models/range';
import { Reference, reference, bookReference } from './models/reference';
import { Syntax } from './models/syntax';
import { verse } from './models/verse';
import { Number, makeNumber } from './types/number';
import {
  addSpaceAfterBookNumber,
  getUnnumberedBookAliases,
  parseNumber,
  normalizeSpacing,
  trimTrailingPeriod,
} from './utils';
import { BookKey, BookIdPair, bookKey } from './indexers';

export class Matcher {
  private books: Map<BookKey, Book>;
  private language: Language;
  syntax: Syntax;
  private bookAliasKeys: Set<string>;
  private bookAliases: Map<string, BookIdPair>;

  SPACE: string;
  OPTIONAL_SPACE: string;
  private END: string;
  private COMMA: string;
  COLON: string;
  DASH: string;
  NUMBER: string;
  RANGE: string;
  LIST: string;

  RANGE_OR_NUMBER_COMPILED: RegExp;
  private NUMBER_CAPTURE: RegExp;
  private RANGE_CAPTURE: RegExp;
  CHAPTER_RANGE_CAPTURE: RegExp;
  CHAPTER_VERSES_CAPTURE: RegExp;
  bracketsRegexp: RegExp;
  referenceRegexp: RegExp;

  constructor(
    books: Map<BookKey, Book>,
    bookAliases: Map<string, BookIdPair>,
    language: Language,
    syntax?: Syntax,
  ) {
    this.books = books;
    this.language = language;
    this.syntax = syntax ?? language.syntax;
    this.bookAliasKeys = new Set(bookAliases.keys());
    this.bookAliases = this.expandBookAliases(bookAliases);

    this.SPACE = '\\s+';
    this.OPTIONAL_SPACE = '\\s*';
    this.END = '\\b';
    this.COMMA = '[' + escapeRegex(this.syntax.matchCommas) + ']' + this.OPTIONAL_SPACE;
    this.COLON = '[' + escapeRegex(this.syntax.matchColons) + ']' + this.OPTIONAL_SPACE;
    this.DASH = '[' + escapeRegex(this.syntax.matchDashes) + ']';
    this.NUMBER = '\\d+[a-d]?';
    this.RANGE = `${this.NUMBER}${this.DASH}${this.NUMBER}`;
    this.LIST = `(?:${this.RANGE}|${this.NUMBER})(?:${this.COMMA}(?:${this.RANGE}|${this.NUMBER}))*`;

    this.RANGE_OR_NUMBER_COMPILED = new RegExp(`(${this.RANGE}|${this.NUMBER})`, 'g');
    this.NUMBER_CAPTURE = new RegExp(`(${this.NUMBER})`);
    this.RANGE_CAPTURE = new RegExp(`(${this.NUMBER})${this.DASH}(${this.NUMBER})`);
    this.CHAPTER_RANGE_CAPTURE = new RegExp(
      `${this.END}(${this.NUMBER})${this.COLON}(${this.NUMBER})${this.DASH}` +
        `(${this.NUMBER})${this.COLON}(${this.NUMBER})${this.END}`,
    );
    this.CHAPTER_VERSES_CAPTURE = new RegExp(
      `${this.END}(${this.NUMBER})${this.COLON}(${this.LIST})${this.END}`,
    );

    this.bracketsRegexp = new RegExp(this.buildBracketsRegexp(), 'g');
    this.referenceRegexp = new RegExp(this.buildReferenceRegexp(), 'g');
  }

  buildReferenceRegexp(): string {
    const NAME_PATTERN = this.buildBookNameRegexp();
    const VERSE_MARKER = this.buildVerseMarkerRegexp();
    const NUMBER_LIST = this.buildNumberListRegexp();
    return [
      '(',
      `${this.END}(${NAME_PATTERN})(?!${this.SPACE}[A-Z])`,
      '(',
      `${this.OPTIONAL_SPACE}${this.NUMBER}${this.COLON}${this.NUMBER}${this.DASH}${this.NUMBER}${this.COLON}${this.NUMBER}`,
      '|',
      `${this.OPTIONAL_SPACE}${this.NUMBER}${this.COLON}${NUMBER_LIST}`,
      '|',
      `${this.OPTIONAL_SPACE}${NUMBER_LIST}`,
      ')?',
      ')|(',
      `${this.NUMBER}${this.COLON}${this.NUMBER}${this.DASH}${this.NUMBER}${this.COLON}${this.NUMBER}`,
      '|',
      `${this.NUMBER}${this.COLON}${NUMBER_LIST}`,
      '|',
      `(?:${VERSE_MARKER})${NUMBER_LIST}`,
      ')',
    ].join('');
  }

  expandBookAliases(aliases: Map<string, BookIdPair>): Map<string, BookIdPair> {
    const out = new Map<string, BookIdPair>();
    for (const [alias, libraryBook] of aliases.entries()) {
      out.set(alias, libraryBook);
      for (const [number, prefixes] of Object.entries(this.language.numberPrefixes)) {
        if (alias.startsWith(number + ' ')) {
          for (const prefix of prefixes) {
            out.set(prefix + alias.slice(1), libraryBook);
          }
        }
      }
    }
    return out;
  }

  buildBookNameRegexp(): string {
    const regexpParts: string[] = [];
    for (const number of this.numericalBookPrefixes(true)) {
      const aliases = [...this.bookAliasKeys]
        .filter(a => a.startsWith(number + ' '))
        .map(a => a.slice((number + ' ').length));
      regexpParts.push(
        '(?:' +
          [number, ...this.language.numberPrefixes[number].map(escapeBookName)].join('|') +
          ')' +
          this.OPTIONAL_SPACE +
          '(?:' +
          longNamesFirst(aliases).map(escapeBookName).join('|') +
          ')' +
          '\\b' +
          '\\.?',
      );
    }
    const leadingDigits = /^\d+\s/;
    const unnumbered = [...this.bookAliasKeys].filter(a => !leadingDigits.test(a));
    regexpParts.push(
      '(?:' +
        longNamesFirst(unnumbered).map(escapeBookName).join('|') +
        ')' +
        '\\b' +
        '\\.?',
    );
    return regexpParts.join('|');
  }

  buildVerseMarkerRegexp(): string {
    return this.language.verseMarkers
      .map(key => escapeRegex(key) + this.OPTIONAL_SPACE)
      .join('|');
  }

  buildNumberListRegexp(): string {
    const regexpParts: string[] = [];
    for (const number of this.numericalBookPrefixes(false)) {
      const aliases = [...this.bookAliases.keys()]
        .filter(a => a.startsWith(number + ' '))
        .map(a => a.slice((number + ' ').length));
      regexpParts.push(
        number +
          '(?!' +
          this.COLON +
          '|' +
          '\\s*' +
          '(?:' +
          [...new Set(aliases)].sort().map(escapeRegex).join('|') +
          '))',
      );
    }
    regexpParts.push(
      `(?:[${regexpParts.length + 1}-9]|\\d{2,3})(?!${this.COLON})`,
    );
    const VERSE_NUMBER = regexpParts.join('|');
    return `(?:${this.RANGE}|${this.NUMBER})(?:${this.COMMA}(?:${this.RANGE}|(?:${VERSE_NUMBER})${this.END}))*`;
  }

  numericalBookPrefixes(reverse = true): string[] {
    const prefixes = new Set<string>();
    for (const key of this.bookAliases.keys()) {
      const part1 = key.split(' ')[0];
      if (/^\d+$/.test(part1)) {
        prefixes.add(part1);
      }
    }
    return [...prefixes].sort((a, b) => (reverse ? b.localeCompare(a) : a.localeCompare(b)));
  }

  buildBracketsRegexp(): string {
    return '[()]';
  }

  *generateReferences(
    text: string,
    yieldBooks = false,
    yieldNones = false,
    useContext = true,
  ): Generator<[string, Reference | null]> {
    const bracketsIter = text.matchAll(new RegExp(this.buildBracketsRegexp(), 'g'));
    const referenceIter = text.matchAll(new RegExp(this.buildReferenceRegexp(), 'g'));

    const bracketStack: Range[] = [];

    let bm = nextMatch(bracketsIter);
    let rm = nextMatch(referenceIter);

    const unnumberedBookAliases = getUnnumberedBookAliases(this.bookAliases);

    while (rm !== null || bm !== null) {
      const bmPos = bm !== null ? bm.index! : Infinity;
      const rmPos = rm !== null ? rm.index! : Infinity;

      let bookRef: Reference | null = null;
      const bracketFirst = bmPos < rmPos;

      if (bm !== null && bracketFirst) {
        if (bm[0] === '(') {
          if (bracketStack.length > 0) {
            bracketStack.push(bracketStack[bracketStack.length - 1]);
          }
        } else if (bm[0] === ')') {
          if (bracketStack.length > 0) {
            bracketStack.pop();
          }
        }
        bm = nextMatch(bracketsIter);
      }

      if (rm !== null && !bracketFirst) {
        const matchStr = rm[1];
        const bookName = rm[2];
        const matchWithBook = rm[3];
        const matchWithoutBook = rm[4];

        try {
          if (bookName) {
            const respaced = addSpaceAfterBookNumber(
              normalizeSpacing(trimTrailingPeriod(bookName)),
              unnumberedBookAliases,
              this.language.numberPrefixes,
            );

            if (this.bookAliases.has(respaced)) {
              const [libraryId, bookId] = this.bookAliases.get(respaced)!;
              const book = this.books.get(bookKey(libraryId, bookId))!;
              const lastRange = bookReference(libraryId, bookId).lastRange();

              if (matchWithBook) {
                let matches: RegExpExecArray | null;
                let numberMatches: string[];
                if ((matches = this.matchChapterRange(matchWithBook))) {
                  bookRef = makeChapterRange(lastRange, matches);
                  if (bookRef !== null || yieldNones) yield [matchStr, bookRef];
                } else if ((matches = this.matchChapterVerses(matchWithBook))) {
                  bookRef = this.makeChapterVerses(lastRange, matches);
                  if (bookRef !== null || yieldNones) yield [matchStr, bookRef];
                } else if ((numberMatches = this.matchNumberRanges(matchWithBook)).length > 0) {
                  if (book.chapters === 1) {
                    const v = verseRange(lastRange.start.library, lastRange.start.book, makeNumber(1), makeNumber(1));
                    bookRef = this.makeNumberRanges(v, numberMatches);
                    if (bookRef !== null || yieldNones) yield [matchStr, bookRef];
                  }
                  if (book.chapters > 1) {
                    bookRef = this.makeNumberRanges(lastRange, numberMatches, true);
                    if (bookRef !== null || yieldNones) yield [matchStr, bookRef];
                  }
                } else {
                  yield [matchStr, null];
                }
              } else {
                if (bracketStack.length > 0) {
                  bracketStack[bracketStack.length - 1] = lastRange;
                } else {
                  bracketStack.push(lastRange);
                }
                if (yieldBooks && !this.language.ambiguousAliases.includes(trimTrailingPeriod(matchStr))) {
                  yield [matchStr, bookReference(libraryId, bookId)];
                }
              }
            }
          } else if (matchWithoutBook && useContext) {
            if (bracketStack.length > 0) {
              const lastRange = bracketStack[bracketStack.length - 1];
              let matches: RegExpExecArray | null;
              let numberMatches: string[];
              if ((matches = this.matchChapterRange(matchWithoutBook))) {
                bookRef = makeChapterRange(lastRange, matches);
                if (bookRef !== null || yieldNones) yield [matchWithoutBook, bookRef];
              } else if ((matches = this.matchChapterVerses(matchWithoutBook))) {
                bookRef = this.makeChapterVerses(lastRange, matches);
                if (bookRef !== null || yieldNones) yield [matchWithoutBook, bookRef];
              } else if ((numberMatches = this.matchNumberRanges(matchWithoutBook)).length > 0) {
                bookRef = this.makeNumberRanges(lastRange, numberMatches);
                if (bookRef !== null || yieldNones) yield [matchWithoutBook, bookRef];
              } else {
                if (yieldNones) yield [matchWithoutBook, null];
              }
            } else {
              if (yieldNones) yield [matchWithoutBook, null];
            }
          }
        } catch {
          if (yieldNones) yield [matchStr ?? matchWithoutBook, null];
        }

        if (bookRef) {
          const lr = bookRef.ranges[bookRef.ranges.length - 1];
          if (bracketStack.length > 0) {
            bracketStack[bracketStack.length - 1] = lr;
          } else {
            bracketStack.push(lr);
          }
        }

        rm = nextMatch(referenceIter);
      }
    }
  }

  matchChapterRange(text: string): RegExpExecArray | null {
    return this.CHAPTER_RANGE_CAPTURE.exec(text);
  }

  matchChapterVerses(text: string): RegExpExecArray | null {
    return this.CHAPTER_VERSES_CAPTURE.exec(text);
  }

  matchNumberRanges(text: string): string[] {
    const regexp = new RegExp(this.RANGE_OR_NUMBER_COMPILED.source, 'g');
    return [...text.matchAll(regexp)].map(m => m[1]);
  }

  makeNumberRanges(
    last: Range,
    matches: string[],
    asChapters = false,
  ): Reference | null {
    const ranges: Range[] = [];
    for (const text of matches) {
      let start: string;
      let end: string;
      const rangeMatch = this.RANGE_CAPTURE.exec(text);
      if (rangeMatch && rangeMatch.index === 0) {
        start = rangeMatch[1];
        end = rangeMatch[2];
      } else {
        const numMatch = this.NUMBER_CAPTURE.exec(text);
        if (!numMatch) continue;
        start = end = numMatch[1];
      }
      if (parseNumber(end) < parseNumber(start)) {
        const inferred = inferAbbreviation(start, end);
        if (inferred !== null) {
          end = inferred;
        } else {
          return null;
        }
      }
      if (asChapters) {
        if (last.isSameBook()) {
          ranges.push(
            range(
              verse(last.start.library, last.start.book, parseNumber(start), makeNumber(1)),
              verse(last.end.library, last.end.book, parseNumber(end), makeNumber(999)),
            ),
          );
        }
      } else {
        if (last.isSameChapter()) {
          ranges.push(
            range(
              verse(last.start.library, last.start.book, last.start.chapter, parseNumber(start)),
              verse(last.end.library, last.end.book, last.end.chapter, parseNumber(end)),
            ),
          );
        }
      }
    }
    return ranges.length > 0 ? reference(...ranges) : null;
  }

  makeChapterVerses(last: Range, match: RegExpExecArray): Reference | null {
    if (last.isSameBook()) {
      const chapter = match[1];
      const numbers = match[2];
      const rangeMatches = this.matchNumberRanges(numbers);
      if (rangeMatches.length > 0) {
        const lastRange = range(
          verse(last.start.library, last.start.book, makeNumber(parseInt(chapter, 10)), makeNumber(1)),
          verse(last.end.library, last.end.book, makeNumber(parseInt(chapter, 10)), makeNumber(999)),
        );
        return this.makeNumberRanges(lastRange, rangeMatches);
      }
    }
    return null;
  }
}

export function makeChapterRange(last: Range, match: RegExpExecArray): Reference | null {
  if (last.isSameBook()) {
    const [c1, v1, c2, v2] = [match[1], match[2], match[3], match[4]];
    return reference(
      range(
        verse(last.start.library, last.start.book, parseNumber(c1), parseNumber(v1)),
        verse(last.end.library, last.end.book, parseNumber(c2), parseNumber(v2)),
      ),
    );
  }
  return null;
}

function escapeRegex(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\-]/g, '\\$&');
}

function escapeBookName(name: string): string {
  return name.split(' ').map(escapeRegex).join('\\s+');
}

function longNamesFirst(names: string[]): string[] {
  return [...new Set(names)].sort((a, b) => b.length - a.length);
}

export function inferAbbreviation(start: string, end: string): string | null {
  if (parseInt(end, 10) < parseInt(start, 10)) {
    if (end.length < start.length) {
      return start.slice(0, start.length - end.length) + end;
    }
    return null;
  }
  return end;
}

function nextMatch(iter: IterableIterator<RegExpMatchArray>): RegExpMatchArray | null {
  const result = iter.next();
  return result.done ? null : result.value;
}
