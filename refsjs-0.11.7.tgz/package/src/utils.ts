import { SPACE, NON_BREAKING_SPACE } from './constants';
import { Number, makeNumber } from './types/number';

export function parseNumber(numberStr: string): Number {
  const digits = numberStr.replace(/\D/g, '');
  if (digits !== '') {
    const n = parseInt(digits, 10);
    if (n >= 1 && n <= 999) {
      return makeNumber(n);
    }
  }
  throw new Error(`Invalid number string for parseNumber: '${numberStr}'`);
}

export function urlEscape(name: string): string {
  return name
    .replace(new RegExp(SPACE, 'g'), '%20')
    .replace(new RegExp(NON_BREAKING_SPACE, 'g'), '%20')
    .replace(/:/g, '%3A')
    .replace(/–/g, '-');
}

export function urlParam(name: string): string {
  return name.toLowerCase().replace(/ /g, '+').replace(/:/g, '.').replace(/–/g, '-');
}

export function stripBookNumber(name: string): string {
  return name.replace(/^\d /, '');
}

export function getUnnumberedBookAliases(bookAliases: Map<string, unknown>): Set<string> {
  const unique = new Set<string>();
  for (const alias of bookAliases.keys()) {
    unique.add(stripBookNumber(alias));
  }
  return unique;
}

export function stripSpaceAfterBookNumber(name: string): string {
  return name.replace(/^(\d) (.*)$/, '$1$2');
}

export function addSpaceAfterBookNumber(
  name: string,
  unnumberedBookAliases: Set<string>,
  numberPrefixes: Record<string, string[]>,
): string {
  if (name.includes(' ')) {
    return name;
  }
  const sortedEntries = Object.entries(numberPrefixes).sort(([a], [b]) => b.localeCompare(a));
  for (const [number, prefixes] of sortedEntries) {
    for (const prefix of prefixes) {
      const head = name.slice(0, prefix.length);
      const tail = name.slice(prefix.length);
      if (head === prefix && unnumberedBookAliases.has(tail)) {
        return number + ' ' + tail;
      }
    }
  }
  return name.replace(/^(\d)([A-Z])([a-z].*)$/, '$1 $2$3');
}

export function trimTrailingPeriod(text: string): string {
  return text.replace(/\.$/, '');
}

export function normalizeSpacing(text: string): string {
  return text.replace(/\s+/g, ' ');
}

export function pluralize(count: number, singular: string, plural = ''): string {
  if (count === 1) {
    return `${count} ${singular}`;
  }
  return plural !== '' ? `${count} ${plural}` : `${count} ${singular}s`;
}

export function sequentialReplaceTuples(
  text: string,
  tuples: [string, string][],
): string {
  let result = '';
  let cursor = 0;
  for (const [find, replace] of tuples) {
    if (find && replace) {
      const nextMatch = text.indexOf(find, cursor);
      if (nextMatch !== -1) {
        result += text.slice(cursor, nextMatch);
        result += replace;
        cursor = nextMatch + find.length;
      }
    }
  }
  result += text.slice(cursor);
  return result;
}

export function sequentialReplace(
  text: string,
  find: string[],
  replace: string[],
): string {
  const tuples = find.map((f, i) => [f, replace[i]] as [string, string]);
  return sequentialReplaceTuples(text, tuples);
}

export function stringTogether(...args: unknown[]): string {
  return args.map(String).join('');
}
