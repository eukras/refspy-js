import { Language } from './models/language';
import { Library } from './models/library';
import { Syntax, syntaxLabel } from './models/syntax';

import { ENGLISH } from './languages/english';
import { FRENCH } from './languages/french';

import { OT as EN_OT, DC as EN_DC, DC_ORTHODOX as EN_DC_ORTHODOX, NT as EN_NT } from './libraries/en_US';
import { OT as FR_OT, DC as FR_DC, DC_ORTHODOX as FR_DC_ORTHODOX, NT as FR_NT } from './libraries/fr_FR';

import { INTERNATIONAL } from './syntax/international';
import { EUROPEAN } from './syntax/european';

export const LIBRARIES: Record<string, Record<string, Library[]>> = {
  protestant: {
    en_US: [EN_OT, EN_NT],
    fr_FR: [FR_OT, FR_NT],
  },
  catholic: {
    en_US: [EN_OT, EN_DC, EN_NT],
    fr_FR: [FR_OT, FR_DC, FR_NT],
  },
  orthodox: {
    en_US: [EN_OT, EN_DC, EN_DC_ORTHODOX, EN_NT],
    fr_FR: [FR_OT, FR_DC, FR_DC_ORTHODOX, FR_NT],
  },
};

export const LANGUAGES: Record<string, Language> = {
  en: ENGLISH,
  fr: FRENCH,
};

export const SYNTAX: Record<string, Syntax> = {
  euro: EUROPEAN,
  intl: INTERNATIONAL,
};

export const LANGUAGE_OPTIONS: [string, string, string][] = [
  ['en_US', 'English', 'intl'],
  ['fr_FR', 'French', 'euro'],
];

export const SYNTAX_OPTIONS: [string, string][] = [
  [INTERNATIONAL.abbrev, syntaxLabel(INTERNATIONAL)],
  [EUROPEAN.abbrev, syntaxLabel(EUROPEAN)],
];
