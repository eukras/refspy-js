import { makeNumber } from '../src/types/number';
import { ENGLISH } from '../src/languages/english';
import { NT } from '../src/libraries/en_US';
import { Manager } from '../src/manager';
import { Book } from '../src/models/book';
import { Library } from '../src/models/library';
import { range } from '../src/models/range';
import { reference, verseReference } from '../src/models/reference';
import { verse } from '../src/models/verse';

const n = makeNumber;

const BOOK: Book = { id: n(2), name: 'Book', abbrev: 'Bk', aliases: ['vol'], chapters: 3 };
const LIBRARY: Library = { id: n(1), name: 'Library', abbrev: 'Lib', books: [BOOK] };
const REFERENCES = [
  reference(range(verse(LIBRARY.id, BOOK.id, n(1), n(1)), verse(LIBRARY.id, BOOK.id, n(1), n(2)))),
];
const __ = new Manager([LIBRARY], ENGLISH);

test('init', () => {
  expect(__.libraries.get(LIBRARY.id)).toEqual(LIBRARY);
  expect(__.bookAliases.get('Book')).toEqual([LIBRARY.id, BOOK.id]);
});

test('make index references', () => {
  const tuples = __.findReferences('Book 1:2, 2:1, 3:4, 1:4-5, 7, 3:6');
  const refs = __.makeIndexReferences(tuples.map(([, ref]) => ref).filter(ref => ref !== null) as any);
  expect(refs.map(ref => __.template(ref)).join(','))
    .toBe('Bk 1:2, 4–5, 7; 2:1; 3:4, 6');
});

test('make index', () => {
  const tuples = __.findReferences('Book 1:2, 2:1, 3:4, 1:4-5, 7, 3:6');
  const text = __.makeIndex(tuples.map(([, ref]) => ref).filter(ref => ref !== null) as any);
  expect(text).toBe('Bk 1:2, 4–5, 7; 2:1; 3:4, 6');
});

test('make hotspots', () => {
  const tuples = __.findReferences('Book 1:2, 2:1, 3:4, 1:4-5, 7, 3:6');
  const out = __.makeHotspots(
    tuples.map(([, ref]) => ref).filter(ref => ref !== null) as any,
    2, 2,
  );
  expect(out).toBe('Bk 1, Bk 3');
});

test('make hotspots lots', () => {
  const tuples = __.findReferences('Book 1:2, 2:1, 3:4, 1:4-5, 7, 3:6, '.repeat(100));
  const out = __.makeHotspots(
    tuples.map(([, ref]) => ref).filter(ref => ref !== null) as any,
    2, 2,
  );
  expect(out).toBe('Bk 1, Bk 3');
});

test('make hotspots empty', () => {
  expect(__.makeHotspots([], 2, 2)).toBeNull();
});

test('non unique', () => {
  expect(() => new Manager([LIBRARY, LIBRARY], ENGLISH)).toThrow();
});

test('sort references', () => {
  const ref1 = verseReference(NT.id, n(1), n(2), n(3));
  const ref2 = verseReference(NT.id, n(1), n(2), n(4));
  const ref3 = verseReference(NT.id, n(1), n(2), n(5));
  const sorted = __.sortReferences([ref3, ref2, ref1]);
  expect(sorted.ranges).toEqual([ref1.ranges[0], ref2.ranges[0], ref3.ranges[0]]);
});

test('merge references', () => {
  const ref1 = verseReference(NT.id, n(1), n(2), n(3));
  const ref2 = verseReference(NT.id, n(1), n(2), n(3), n(4));
  const ref3 = verseReference(NT.id, n(1), n(2), n(4), n(5));
  const merged = __.mergeReferences([ref3, ref2, ref1]);
  expect(merged.ranges.length).toBe(1);
  expect(merged).toEqual(verseReference(NT.id, n(1), n(2), n(3), n(5)));
});

test('combine references', () => {
  const ref1 = verseReference(NT.id, n(1), n(2), n(3));
  const ref2 = verseReference(NT.id, n(1), n(2), n(4));
  const ref3 = verseReference(NT.id, n(1), n(2), n(5), n(6));
  const combined = __.combineReferences([ref3, ref2, ref1]);
  expect(combined.ranges.length).toBe(1);
  expect(combined).toEqual(verseReference(NT.id, n(1), n(2), n(3), n(6)));
});

test('collate by book', () => {
  const collation = __.collateByBook(REFERENCES);
  for (const [libraryId, bookCollation] of collation.entries()) {
    expect(libraryId).toBe(LIBRARY.id);
    for (const [bookId, bookRefs] of bookCollation.entries()) {
      expect(bookId).toBe(BOOK.id);
      expect(bookRefs).toEqual(REFERENCES);
    }
  }
});

test('collate by chapter', () => {
  const collation = __.collateByChapter(REFERENCES);
  for (const [libraryId, bookCollation] of collation.entries()) {
    expect(libraryId).toBe(LIBRARY.id);
    for (const [bookId, chapterCollation] of bookCollation.entries()) {
      expect(bookId).toBe(BOOK.id);
      for (const [chapterId, chapterRefs] of chapterCollation.entries()) {
        expect(chapterId).toBe(1);
        expect(chapterRefs).toEqual(REFERENCES);
      }
    }
  }
});

test('collate by verse', () => {
  const collation = __.collateByVerse(REFERENCES);
  for (const [libraryId, bookCollation] of collation.entries()) {
    expect(libraryId).toBe(LIBRARY.id);
    for (const [bookId, chapterCollation] of bookCollation.entries()) {
      expect(bookId).toBe(BOOK.id);
      for (const [chapterId, verseCollation] of chapterCollation.entries()) {
        expect(chapterId).toBe(1);
        for (const [, verseRefs] of verseCollation.entries()) {
          expect(verseRefs).toEqual(REFERENCES);
        }
      }
    }
  }
});

test('collate', () => {
  const collation = __.collate(REFERENCES);
  for (const [library, bookCollation] of collation) {
    expect(library).toEqual(LIBRARY);
    for (const [book, bookRefs] of bookCollation) {
      expect(book).toEqual(BOOK);
      expect(bookRefs).toEqual(REFERENCES);
    }
  }
});

test('collate book references', () => {
  const collation = __.collateBookReferences(REFERENCES);
  for (const [library, bookCollation] of collation) {
    expect(library).toEqual(LIBRARY);
    for (const [book, bookRefs] of bookCollation) {
      expect(book).toEqual(BOOK);
      expect(bookRefs).toEqual(REFERENCES);
    }
  }
});

test('collate chapter references', () => {
  const collation = __.collateChapterReferences(REFERENCES);
  for (const [library, bookCollation] of collation) {
    expect(library).toEqual(LIBRARY);
    for (const [book, chapterCollation] of bookCollation) {
      expect(book).toEqual(BOOK);
      for (const [chapterId, refs] of chapterCollation) {
        expect(chapterId).toBe(1);
        expect(refs).toEqual(REFERENCES);
      }
    }
  }
});

test('first reference', () => {
  const [, ref] = __.firstReference('Book 1:1');
  expect(ref).not.toBeNull();
  expect(__.name(ref!)).toBe('Book 1:1');
});

test('find references', () => {
  const tuples = __.findReferences('Book 1:1–2:4');
  const [, ref] = tuples[0];
  expect(ref).not.toBeNull();
  expect(__.name(ref!)).toBe('Book 1:1–2:4');
});

test('find all', () => {
  const text = 'Book 1:1, Book 2:2';
  const tuples = __.findReferences(text);
  expect(tuples[0]).toEqual(['Book 1:1', __.r('Book 1:1')]);
  expect(tuples[1]).toEqual(['Book 2:2', __.r('Book 2:2')]);
});

test('next chapter', () => {
  const mgr = new Manager([LIBRARY], ENGLISH);
  const ch1 = mgr.bcv('Book', n(1));
  const ch2 = mgr.bcv('Book', n(2));
  expect(mgr.nextChapter(ch1)).toEqual(ch2);
});

test('prev chapter', () => {
  const mgr = new Manager([LIBRARY], ENGLISH);
  const ch2 = mgr.bcv('Book', n(2));
  const ch1 = mgr.bcv('Book', n(1));
  expect(mgr.prevChapter(ch2)).toEqual(ch1);
});

test('bcv', () => {
  const bk = __.bcv('Book');
  expect(__.name(bk)).toBe('Book');
  const bk2 = __.bcv('Book', n(2));
  expect(__.name(bk2)).toBe('Book 2');
  const bk21 = __.bcv('Book', n(2), n(1));
  expect(__.name(bk21)).toBe('Book 2:1');
});

test('bcr', () => {
  const bk2135 = __.bcr('Book', n(2), [n(1), n(3), n(5)]);
  expect(__.name(bk2135)).toBe('Book 2:1, 3, 5');
  const bk21357 = __.bcr('Book', n(2), [[n(1), n(3)], [n(5), n(7)]]);
  expect(__.name(bk21357)).toBe('Book 2:1–3, 5–7');
});

test('r', () => {
  let ref = __.r('Book 1:1');
  expect(ref).not.toBeNull();
  expect(__.name(ref!)).toBe('Book 1:1');
  ref = __.r('Book 1:1, 3');
  expect(ref).not.toBeNull();
  expect(__.name(ref!)).toBe('Book 1:1, 3');
  ref = __.r('Book 1:1-3');
  expect(ref).not.toBeNull();
  expect(__.name(ref!)).toBe('Book 1:1–3');
  ref = __.r('Book 1:1-3, 5-7');
  expect(ref).not.toBeNull();
  expect(__.name(ref!)).toBe('Book 1:1–3, 5–7');
  ref = __.r('Book 1:1–2:4');
  expect(ref).not.toBeNull();
  expect(__.name(ref!)).toBe('Book 1:1–2:4');
  ref = __.r('Book 1:1-2:4');
  expect(ref).not.toBeNull();
  expect(__.name(ref!)).toBe('Book 1:1–2:4');
});

test('get book', () => {
  const ref = __.r('Book 1:1');
  expect(ref).not.toBeNull();
  const book = __.getBook(ref!);
  expect(book.name).toBe('Book');
});

test('book reference method', () => {
  const ref = __.r('Book 1:1');
  expect(ref).not.toBeNull();
  const bookRef = __.bookReference(ref!);
  expect(__.name(bookRef)).toBe('Book');
});

test('chapter reference method', () => {
  const ref = __.r('Book 1:1');
  expect(ref).not.toBeNull();
  const chapRef = __.chapterReference(ref!);
  expect(__.name(chapRef)).toBe('Book 1');
});

test('name', () => {
  const ref = __.r('Book 1:1');
  expect(ref).not.toBeNull();
  expect(__.name(ref!)).toBe('Book 1:1');
});

test('book', () => {
  const ref = __.r('Book 1:1');
  expect(ref).not.toBeNull();
  expect(__.book(ref!)).toBe('Book');
});

test('numbers', () => {
  const ref = __.r('Book 1:1');
  expect(ref).not.toBeNull();
  expect(__.numbers(ref!)).toBe('1:1');
});

test('abbrev name', () => {
  const ref = __.r('Book 1:1');
  expect(ref).not.toBeNull();
  expect(__.abbrevName(ref!)).toBe('Bk 1:1');
});

test('abbrev book', () => {
  const ref = __.r('Book 1:1');
  expect(ref).not.toBeNull();
  expect(__.abbrevBook(ref!)).toBe('Bk');
});

test('template', () => {
  const ref = __.r('1 Cor 2:3-4, 5');
  if (ref !== null) {
    expect(__.template(ref, 'x {NAME}')).toBe('x 1 Corinthians 2:3–4, 5');
    expect(__.template(ref, 'x {BOOK}')).toBe('x 1 Corinthians');
    expect(__.template(ref, 'x {NUMBERS}')).toBe('x 2:3–4, 5');
    expect(__.template(ref, 'x {ABBREV_NAME}')).toBe('x 1 Cor 2:3–4, 5');
    expect(__.template(ref, 'x {ABBREV_BOOK}')).toBe('x 1 Cor');
    expect(__.template(ref, 'x {ESC_NAME}')).toBe('x 1%20Corinthians%202%3A3-4,%205');
    expect(__.template(ref, 'x {ESC_BOOK}')).toBe('x 1%20Corinthians');
    expect(__.template(ref, 'x {ESC_NUMBERS}')).toBe('x 2%3A3-4,%205');
    expect(__.template(ref, 'x {ESC_ABBREV_NAME}')).toBe('x 1%20Cor%202%3A3-4,%205');
    expect(__.template(ref, 'x {ESC_ABBREV_BOOK}')).toBe('x 1%20Cor');
    expect(__.template(ref, 'x {PARAM_NAME}')).toBe('x 1cor+2:3-4,+5');
    expect(__.template(ref, 'x {PARAM_BOOK}')).toBe('x 1cor');
    expect(__.template(ref, 'x {PARAM_NUMBERS}')).toBe('x 2:3-4,+5');
  }
});
