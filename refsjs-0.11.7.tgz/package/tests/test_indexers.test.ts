import { makeNumber } from '../src/types/number';
import {
  addUniqueBookAlias,
  indexBookAliases,
  indexBooks,
  indexLibraries,
  bookKey,
} from '../src/indexers';
import { Book } from '../src/models/book';
import { Library } from '../src/models/library';
import { BookIdPair } from '../src/indexers';

const n = makeNumber;

const bk1: Book = { id: n(1), name: 'Book', abbrev: 'Bk', aliases: ['vol'], chapters: 10 };
const bk2: Book = { id: n(2), name: 'Book', abbrev: 'Bk', aliases: [], chapters: 10 };
const bk3: Book = { id: n(3), name: '3 Book', abbrev: '3 Bk', aliases: [], chapters: 1 };

const lib1: Library = { id: n(1), name: 'Library', abbrev: 'Lib', books: [bk1] };
const lib2: Library = { id: n(2), name: 'Library', abbrev: 'Lib', books: [bk1, bk2, bk3] };

test('book uniqueness', () => {
  const index = new Map<string, BookIdPair>();
  addUniqueBookAlias(index, 'Library', n(1), n(1), true);
  addUniqueBookAlias(index, 'Other Library', n(1), n(2), true);
  expect(() => addUniqueBookAlias(index, 'Library', n(1), n(3), true)).toThrow();
});

test('index books', () => {
  const index = indexBooks([lib2]);
  expect(index.size).toBe(3);
  expect(index.get(bookKey(n(2), n(1)))).toEqual(bk1);
  expect(index.get(bookKey(n(2), n(2)))).toEqual(bk2);
});

test('index book aliases', () => {
  const index = indexBookAliases([lib1]);
  expect(index.size).toBe(3); // 'Book', 'Bk', 'vol'
  expect(index.get('Book')).toEqual([n(1), n(1)]);
  expect(index.get('Bk')).toEqual([n(1), n(1)]);
});

test('index libraries', () => {
  const index = indexLibraries([lib1]);
  expect(index.size).toBe(1);
  expect(index.get(n(1))).toEqual(lib1);
});
