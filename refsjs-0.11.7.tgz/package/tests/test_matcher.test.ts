import { makeNumber } from '../src/types/number';
import { indexBookAliases, indexBooks } from '../src/indexers';
import { ENGLISH } from '../src/languages/english';
import { FRENCH } from '../src/languages/french';
import {
  Matcher,
  inferAbbreviation,
  makeChapterRange,
} from '../src/matcher';
import { range, verseRange } from '../src/models/range';
import {
  bookReference,
  chapterReference,
  reference,
  verseReference,
} from '../src/models/reference';
import { verse } from '../src/models/verse';
import { INTERNATIONAL } from '../src/syntax/international';
import { TEST_LIBRARY } from './data';

const books = indexBooks([TEST_LIBRARY]);
const bookAliases = indexBookAliases([TEST_LIBRARY]);
const matcher = new Matcher(books, bookAliases, ENGLISH);
const matcherFr = new Matcher(books, bookAliases, FRENCH);
const matcherFrIntl = new Matcher(books, bookAliases, FRENCH, INTERNATIONAL);

function findall(regexp: RegExp, text: string): string[] {
  return [...text.matchAll(new RegExp(regexp.source, regexp.flags.includes('g') ? regexp.flags : regexp.flags + 'g'))].map(m => m[0]);
}

function findallGroups(regexp: RegExp, text: string): [string, string, string, string][] {
  const re = new RegExp(regexp.source, regexp.flags.includes('g') ? regexp.flags : regexp.flags + 'g');
  return [...text.matchAll(re)].map(m => [m[1] ?? '', m[2] ?? '', m[3] ?? '', m[4] ?? '']);
}

function findallPattern(pattern: string, text: string): string[] {
  return [...text.matchAll(new RegExp(pattern, 'g'))].map(m => m[0]);
}

const n = makeNumber;

test('regexp building blocks', () => {
  expect(findallPattern(matcher.COLON, ':')).toEqual([':']);
  expect(findallPattern(matcher.DASH, '-')).toEqual(['-']);
  expect(findallPattern(matcher.DASH, '–')).toEqual(['–']);
  expect(findallPattern(matcher.NUMBER, '0')).toEqual(['0']);
  expect(findallPattern(matcher.NUMBER, '1')).toEqual(['1']);
  expect(findallPattern(matcher.NUMBER, '1000')).toEqual(['1000']);
  expect(findallPattern(matcher.SPACE, ' ')).toEqual([' ']);
  expect(findallPattern(matcher.SPACE, '\n')).toEqual(['\n']);
  expect(findallPattern(matcher.SPACE, '\r')).toEqual(['\r']);
  expect(findallPattern(matcher.SPACE, '\t')).toEqual(['\t']);
  expect(findallPattern(matcher.OPTIONAL_SPACE, '')).toEqual(['']);
  expect(findallPattern(matcher.OPTIONAL_SPACE, ' ')).toEqual([' ', '']);
  expect(findallPattern(matcher.OPTIONAL_SPACE, '\n')).toEqual(['\n', '']);
  expect(findallPattern(matcher.OPTIONAL_SPACE, '\r')).toEqual(['\r', '']);
  expect(findallPattern(matcher.OPTIONAL_SPACE, '\t')).toEqual(['\t', '']);
  expect(findallPattern(matcher.RANGE, '1-2')).toEqual(['1-2']);
  expect(findallPattern(matcher.RANGE, '0-999')).toEqual(['0-999']);
  expect(findallPattern(matcher.RANGE, '1-1000')).toEqual(['1-1000']);
  expect(findallPattern(matcher.RANGE, '1-999')).toEqual(['1-999']);
});

test('number list regexp', () => {
  expect(findallPattern(matcher.LIST, '1-3,4:5,7-9')).toEqual(['1-3,4', '5,7-9']);
  expect(findallPattern(matcher.LIST, '1-3,4,5, 7-9')).toEqual(['1-3,4,5, 7-9']);
  expect(findallPattern(matcher.LIST, '11-13,14,15, 17-19')).toEqual(['11-13,14,15, 17-19']);
  expect(findallPattern(matcher.LIST, '111-113,114,115, 117-119')).toEqual(['111-113,114,115, 117-119']);
});

test('number list generated regexp', () => {
  const numberList = matcher.buildNumberListRegexp();
  expect(findallPattern(numberList, 'Big Book 1:1, 1, 1 Book 2, 3, 4:5')).toEqual(['1', '1, 1', '1', '2, 3', '4', '5']);
  expect(findallPattern(numberList, 'Big Book 11:11, 12, 1 Book 12, 13, 14:15')).toEqual(['11', '11, 12', '1', '12, 13', '14', '15']);
});

test('range or number regexp', () => {
  expect([...'1,2-3, 4,   5-6'.matchAll(new RegExp(matcher.RANGE_OR_NUMBER_COMPILED.source, 'g'))].map(m => m[1])).toEqual(['1', '2-3', '4', '5-6']);
  expect([...'11,12-13, 14,   15-16'.matchAll(new RegExp(matcher.RANGE_OR_NUMBER_COMPILED.source, 'g'))].map(m => m[1])).toEqual(['11', '12-13', '14', '15-16']);
});

test('chapter range regexp', () => {
  const match = matcher.CHAPTER_RANGE_CAPTURE.exec(' 1:2-3:4');
  expect(match).not.toBeNull();
  expect(match![1]).toBe('1');
  expect(match![2]).toBe('2');
  expect(match![3]).toBe('3');
  expect(match![4]).toBe('4');
});

test('chapter verses regexp', () => {
  const match = matcher.CHAPTER_VERSES_CAPTURE.exec(' 1:2,3-4');
  expect(match).not.toBeNull();
  expect(match![1]).toBe('1');
  expect(match![2]).toBe('2,3-4');
});

test('name regexp', () => {
  const regexp = matcher.buildReferenceRegexp();
  expect(regexp).toContain('Big\\s+Book');
  expect(regexp).toContain('Small\\s+Book');
});

test('match brackets', () => {
  const text = 'Big Book 1:2-5 (and 34:6 (and 7)) are more interesting than Small Book 3-6.';
  const matches = findall(matcher.bracketsRegexp, text);
  expect(matches.length).toBe(4);
  expect(matches[0]).toBe('(');
  expect(matches[1]).toBe('(');
  expect(matches[2]).toBe(')');
  expect(matches[3]).toBe(')');
});

test('match names', () => {
  expect(findallGroups(matcher.referenceRegexp, 'Big Book')).toEqual([['Big Book', 'Big Book', '', '']]);
  expect(findallGroups(matcher.referenceRegexp, 'Big')).toEqual([['Big', 'Big', '', '']]);
  expect(findallGroups(matcher.referenceRegexp, 'Small Book')).toEqual([['Small Book', 'Small Book', '', '']]);
  expect(findallGroups(matcher.referenceRegexp, 'Small')).toEqual([['Small', 'Small', '', '']]);
});

test('does not match human first names', () => {
  expect(findallGroups(matcher.referenceRegexp, 'Big Bob')).toEqual([]);
  expect(findallGroups(matcher.referenceRegexp, 'Big B.')).toEqual([]);
});

test('match names and numbers', () => {
  expect(findallGroups(matcher.referenceRegexp, 'Big Book 1')).toEqual([['Big Book 1', 'Big Book', ' 1', '']]);
  expect(findallGroups(matcher.referenceRegexp, 'Big Book 1-2')).toEqual([['Big Book 1-2', 'Big Book', ' 1-2', '']]);
  expect(findallGroups(matcher.referenceRegexp, 'Big Book 1-2,4,6')).toEqual([['Big Book 1-2,4,6', 'Big Book', ' 1-2,4,6', '']]);
});

test('verse lists with abbreviations', () => {
  expect(findallGroups(matcher.referenceRegexp, 'Big 1:1')).toEqual([['Big 1:1', 'Big', ' 1:1', '']]);
  expect(findallGroups(matcher.referenceRegexp, 'Big 1:1, 2')).toEqual([['Big 1:1, 2', 'Big', ' 1:1, 2', '']]);
  expect(findallGroups(matcher.referenceRegexp, 'Bg 1:1, 2')).toEqual([['Bg 1:1, 2', 'Bg', ' 1:1, 2', '']]);
});

test('malformed refs', () => {
  const matches = matcher.matchNumberRanges('1-2,4-3');
  expect(matches[0]).toBe('1-2');
  expect(matches[1]).toBe('4-3');
});

test('comma separation', () => {
  expect(findallGroups(matcher.referenceRegexp, 'Big Book 1:55, 66, 77')).toEqual([['Big Book 1:55, 66, 77', 'Big Book', ' 1:55, 66, 77', '']]);
});

test('negative lookaheads', () => {
  const matches = findallGroups(matcher.referenceRegexp, 'Big Book 1:1, 2, 1 Book 4');
  expect(matches.length).toBe(2);
  expect(matches[0]).toEqual(['Big Book 1:1, 2', 'Big Book', ' 1:1, 2', '']);
  expect(matches[1]).toEqual(['1 Book 4', '1 Book', ' 4', '']);
});

test('match names in context', () => {
  const text = 'Big Book 1:2-5 and 34:6,7 are more interesting than Small Book 3-6.';
  const matches = findallGroups(matcher.referenceRegexp, text);
  expect(matches.length).toBe(3);
  expect(matches[0]).toEqual(['Big Book 1:2-5', 'Big Book', ' 1:2-5', '']);
  expect(matches[1]).toEqual(['', '', '', '34:6,7']);
  expect(matches[2]).toEqual(['Small Book 3-6', 'Small Book', ' 3-6', '']);
});

test('match number ranges numeric', () => {
  const lastRange = verseRange(n(1), n(1), n(1), n(1));
  const matches = matcher.matchNumberRanges('1,4-5,7–8, 9');
  const ref = matcher.makeNumberRanges(lastRange, matches);
  expect(ref).not.toBeNull();
  expect(ref!.ranges[0]).toEqual(range(verse(n(1), n(1), n(1), n(1)), verse(n(1), n(1), n(1), n(1))));
  expect(ref!.ranges[1]).toEqual(range(verse(n(1), n(1), n(1), n(4)), verse(n(1), n(1), n(1), n(5))));
  expect(ref!.ranges[2]).toEqual(range(verse(n(1), n(1), n(1), n(7)), verse(n(1), n(1), n(1), n(8))));
  expect(ref!.ranges[3]).toEqual(range(verse(n(1), n(1), n(1), n(9)), verse(n(1), n(1), n(1), n(9))));
});

test('match number ranges prefixed v', () => {
  const lastRange = verseRange(n(1), n(1), n(1), n(1));
  const matches = matcher.matchNumberRanges('v.1,4-5');
  const ref = matcher.makeNumberRanges(lastRange, matches);
  expect(ref).not.toBeNull();
  expect(ref!.ranges[0]).toEqual(range(verse(n(1), n(1), n(1), n(1)), verse(n(1), n(1), n(1), n(1))));
  expect(ref!.ranges[1]).toEqual(range(verse(n(1), n(1), n(1), n(4)), verse(n(1), n(1), n(1), n(5))));
});

test('match number ranges prefixed vv', () => {
  const lastRange = verseRange(n(1), n(1), n(1), n(1));
  const matches = matcher.matchNumberRanges('vv.1,4-5');
  const ref = matcher.makeNumberRanges(lastRange, matches);
  expect(ref).not.toBeNull();
  expect(ref!.ranges[0]).toEqual(range(verse(n(1), n(1), n(1), n(1)), verse(n(1), n(1), n(1), n(1))));
  expect(ref!.ranges[1]).toEqual(range(verse(n(1), n(1), n(1), n(4)), verse(n(1), n(1), n(1), n(5))));
});

test('match chapter range', () => {
  const lastRange = verseRange(n(1), n(1), n(1), n(1));
  let matches = matcher.matchChapterRange('1:4-2:3');
  expect(matches).not.toBeNull();
  let ref = makeChapterRange(lastRange, matches!);
  expect(ref).not.toBeNull();
  expect(ref!.ranges).toEqual([range(verse(n(1), n(1), n(1), n(4)), verse(n(1), n(1), n(2), n(3)))]);
  matches = matcher.matchChapterRange('1:4–2:3');
  expect(matches).not.toBeNull();
  ref = makeChapterRange(lastRange, matches!);
  expect(ref).not.toBeNull();
  expect(ref!.ranges).toEqual([range(verse(n(1), n(1), n(1), n(4)), verse(n(1), n(1), n(2), n(3)))]);
});

test('match chapter verses', () => {
  const lastRange = verseRange(n(1), n(1), n(1), n(1));
  const matches = matcher.matchChapterVerses('1:4,8-9');
  expect(matches).not.toBeNull();
  const ref = matcher.makeChapterVerses(lastRange, matches!);
  expect(ref).not.toBeNull();
  expect(ref!.ranges).toEqual([
    range(verse(n(1), n(1), n(1), n(4)), verse(n(1), n(1), n(1), n(4))),
    range(verse(n(1), n(1), n(1), n(8)), verse(n(1), n(1), n(1), n(9))),
  ]);
});

test('match number ranges prefixed vv with space', () => {
  const lastRange = verseRange(n(1), n(1), n(1), n(1));
  const matches = matcher.matchNumberRanges('vv. 1,4-5');
  const ref = matcher.makeNumberRanges(lastRange, matches);
  expect(ref).not.toBeNull();
  expect(ref!.ranges[0]).toEqual(range(verse(n(1), n(1), n(1), n(1)), verse(n(1), n(1), n(1), n(1))));
  expect(ref!.ranges[1]).toEqual(range(verse(n(1), n(1), n(1), n(4)), verse(n(1), n(1), n(1), n(5))));
});

test('find references', () => {
  const sampleText = 'Big Book 1:2-5 and 34:6,7 are more interesting than Small Book 3-6.';
  const gen = matcher.generateReferences(sampleText);
  let result = gen.next();
  expect(result.value[0]).toBe('Big Book 1:2-5');
  expect(result.value[1]).toEqual(reference(range(verse(n(1), n(2), n(1), n(2)), verse(n(1), n(2), n(1), n(5)))));
  result = gen.next();
  expect(result.value[0]).toBe('34:6,7');
  expect(result.value[1]).toEqual(reference(
    range(verse(n(1), n(2), n(34), n(6)), verse(n(1), n(2), n(34), n(6))),
    range(verse(n(1), n(2), n(34), n(7)), verse(n(1), n(2), n(34), n(7))),
  ));
  result = gen.next();
  expect(result.value[0]).toBe('Small Book 3-6');
  expect(result.value[1]).toEqual(reference(range(verse(n(1), n(3), n(1), n(3)), verse(n(1), n(3), n(1), n(6)))));
  expect(gen.next().done).toBe(true);
});

test('vv references', () => {
  const sampleText = 'Big Book 5 is useful, esp. vv.3-4 and v.8.';
  const gen = matcher.generateReferences(sampleText);
  let result = gen.next();
  expect(result.value[0]).toBe('Big Book 5');
  expect(result.value[1]).toEqual(reference(range(verse(n(1), n(2), n(5), n(1)), verse(n(1), n(2), n(5), n(999)))));
  result = gen.next();
  expect(result.value[0]).toBe('vv.3-4');
  expect(result.value[1]).toEqual(reference(range(verse(n(1), n(2), n(5), n(3)), verse(n(1), n(2), n(5), n(4)))));
  result = gen.next();
  expect(result.value[0]).toBe('v.8');
  expect(result.value[1]).toEqual(reference(range(verse(n(1), n(2), n(5), n(8)), verse(n(1), n(2), n(5), n(8)))));
  expect(gen.next().done).toBe(true);
});

test('yield books', () => {
  const sampleText = 'Big Book or Small Book?';
  const gen = matcher.generateReferences(sampleText, true);
  let result = gen.next();
  expect(result.value[0]).toBe('Big Book');
  expect(result.value[1]).toEqual(bookReference(n(1), n(2)));
  result = gen.next();
  expect(result.value[0]).toBe('Small Book');
  expect(result.value[1]).toEqual(bookReference(n(1), n(3)));
  expect(gen.next().done).toBe(true);
});

test('single parentheses', () => {
  const sampleText = 'Big Book 1:2-5 (cf. Small Book 34) is more interesting than vv.3-6.';
  const gen = matcher.generateReferences(sampleText);
  let result = gen.next();
  expect(result.value[0]).toBe('Big Book 1:2-5');
  expect(result.value[1]).toEqual(reference(range(verse(n(1), n(2), n(1), n(2)), verse(n(1), n(2), n(1), n(5)))));
  result = gen.next();
  expect(result.value[0]).toBe('Small Book 34');
  expect(result.value[1]).toEqual(reference(range(verse(n(1), n(3), n(1), n(34)), verse(n(1), n(3), n(1), n(34)))));
  result = gen.next();
  expect(result.value[0]).toBe('vv.3-6');
  expect(result.value[1]).toEqual(reference(range(verse(n(1), n(2), n(1), n(3)), verse(n(1), n(2), n(1), n(6)))));
  expect(gen.next().done).toBe(true);
});

test('number prefixes 1', () => {
  const sampleText = '1 Book 1:1, First Book 1:1, 1st Book 1:1, I Book 1:1';
  const firstReference = verseReference(n(1), n(4), n(1), n(1));
  const gen = matcher.generateReferences(sampleText);
  expect(gen.next().value).toEqual(['1 Book 1:1', firstReference]);
  expect(gen.next().value).toEqual(['First Book 1:1', firstReference]);
  expect(gen.next().value).toEqual(['1st Book 1:1', firstReference]);
  expect(gen.next().value).toEqual(['I Book 1:1', firstReference]);
  expect(gen.next().done).toBe(true);
});

test('number prefixes 2', () => {
  const sampleText = '2 Book 1:1, Second Book 1:1, 2nd Book 1:1, II Book 1:1';
  const firstReference = verseReference(n(1), n(5), n(1), n(1));
  const gen = matcher.generateReferences(sampleText);
  expect(gen.next().value).toEqual(['2 Book 1:1', firstReference]);
  expect(gen.next().value).toEqual(['Second Book 1:1', firstReference]);
  expect(gen.next().value).toEqual(['2nd Book 1:1', firstReference]);
  expect(gen.next().value).toEqual(['II Book 1:1', firstReference]);
  expect(gen.next().done).toBe(true);
});

test('number prefixes 3', () => {
  const sampleText = '3 Book 1, Third Book 1, 3rd Book 1, III Book 1';
  const firstReference = verseReference(n(1), n(6), n(1), n(1));
  const gen = matcher.generateReferences(sampleText);
  expect(gen.next().value).toEqual(['3 Book 1', firstReference]);
  expect(gen.next().value).toEqual(['Third Book 1', firstReference]);
  expect(gen.next().value).toEqual(['3rd Book 1', firstReference]);
  expect(gen.next().value).toEqual(['III Book 1', firstReference]);
  expect(gen.next().done).toBe(true);
});

test('book number spacing is optional', () => {
  const sampleText = '1Book 1:1';
  const firstReference = verseReference(n(1), n(4), n(1), n(1));
  const gen = matcher.generateReferences(sampleText);
  expect(gen.next().value).toEqual(['1Book 1:1', firstReference]);
  expect(gen.next().done).toBe(true);
});

test('line wrapping', () => {
  const text = `
        This is a wrapped reference to 1
        Book 5.
        `;
  const gen = matcher.generateReferences(text);
  const result = gen.next();
  expect(result.value[0]).toBe('1\n        Book 5');
  expect(result.value[1]).toEqual(chapterReference(n(1), n(4), n(5)));
});

test('nonnumeric prefixes', () => {
  const text = '1stBook 6:6 IBook 6:6';
  const gen = matcher.generateReferences(text);
  expect(gen.next().value).toEqual(['1stBook 6:6', verseReference(n(1), n(4), n(6), n(6))]);
  expect(gen.next().value).toEqual(['IBook 6:6', verseReference(n(1), n(4), n(6), n(6))]);
});

test('infer abbreviation', () => {
  expect(inferAbbreviation('124', '24')).toBe('124');
  expect(inferAbbreviation('12', '4')).toBe('14');
  expect(inferAbbreviation('24', '23')).toBeNull();
  expect(inferAbbreviation('4', '3')).toBeNull();
});

test('periods on abbreviations and aliases', () => {
  const text = 'Sm. 1; Bg.1:1';
  const gen = matcher.generateReferences(text);
  expect(gen.next().value).toEqual(['Sm. 1', verseReference(n(1), n(3), n(1), n(1))]);
  expect(gen.next().value).toEqual(['Bg.1:1', verseReference(n(1), n(2), n(1), n(1))]);
});

test('aliases do not match start of words', () => {
  const text = 'Smash and grab';
  const gen = matcher.generateReferences(text, true, true);
  expect(gen.next().done).toBe(true);
});
