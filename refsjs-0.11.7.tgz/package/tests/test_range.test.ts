import { makeNumber } from '../src/types/number';
import {
  Range,
  range,
  bookRange,
  chapterRange,
  verseRange,
  mergeRanges,
  combineRanges,
} from '../src/models/range';
import { verse } from '../src/models/verse';

const n = makeNumber;

test('shorthand', () => {
  const v1 = verse(n(1), n(2), n(3), n(4));
  const v2 = verse(n(1), n(2), n(3), n(5));
  const r = range(v1, v2);
  expect(r.start).toEqual(v1);
  expect(r.end).toEqual(v2);
});

test('construction', () => {
  const v1 = verse(n(1), n(2), n(3), n(4));
  const v2 = verse(n(1), n(2), n(3), n(5));
  const r = new Range(v1, v2);
  expect(r.start).toEqual(v1);
  expect(r.end).toEqual(v2);
});

test('wrong verse order', () => {
  const v1 = verse(n(1), n(2), n(3), n(4));
  const v2 = verse(n(1), n(2), n(3), n(5));
  expect(() => new Range(v2, v1)).toThrow();
});

test('overlaps', () => {
  const r1 = verseRange(n(1), n(2), n(3), n(4), n(8));
  const r2 = verseRange(n(1), n(2), n(3), n(6), n(8));
  const r3 = verseRange(n(1), n(2), n(3), n(9), n(12));
  expect(r1.overlaps(r2)).toBe(true);
  expect(r1.overlaps(r3)).toBe(false);
  expect(r2.overlaps(r3)).toBe(false);
});

test('contains', () => {
  const r1 = verseRange(n(1), n(2), n(3), n(4), n(8));
  const r2 = verseRange(n(1), n(2), n(3), n(6), n(8));
  const r3 = verseRange(n(1), n(2), n(3), n(9), n(12));
  expect(r1.contains(r2)).toBe(true);
  expect(r2.contains(r1)).toBe(false);
  expect(r3.contains(r1)).toBe(false);
});

test('adjoins', () => {
  const vr1 = verseRange(n(1), n(2), n(3), n(3), n(4));
  const vr2 = verseRange(n(1), n(2), n(3), n(5), n(6));
  const cr1 = chapterRange(n(1), n(2), n(3), n(4));
  const cr2 = chapterRange(n(1), n(2), n(5), n(6));
  expect(vr1.adjoins(vr2)).toBe(true);
  expect(vr2.adjoins(vr1)).toBe(true);
  expect(cr1.adjoins(cr2)).toBe(true);
  expect(cr2.adjoins(cr1)).toBe(true);
  expect(cr1.adjoins(vr1)).toBe(false);
  expect(cr2.adjoins(vr2)).toBe(false);
});

test('adjoins chapters', () => {
  const range1 = chapterRange(n(1), n(2), n(3));
  const range2 = chapterRange(n(1), n(2), n(4), n(5));
  expect(range1.adjoins(range2)).toBe(true);
});

test('sorted', () => {
  const range1 = verseRange(n(1), n(2), n(3), n(4), n(6));
  const range2 = verseRange(n(1), n(2), n(3), n(6), n(8));
  const sorted = [range2, range1].sort((a, b) => (a.lt(b) ? -1 : b.lt(a) ? 1 : 0));
  expect(sorted).toEqual([range1, range2]);
});

test('merge overlapping', () => {
  const range1 = verseRange(n(1), n(2), n(3), n(4), n(6));
  const range2 = verseRange(n(1), n(2), n(3), n(6), n(8));
  const range3 = verseRange(n(1), n(2), n(3), n(4), n(8));
  expect(mergeRanges([range2, range1])).toEqual([range3]);
});

test('merge overlapping inter-chapter', () => {
  const range1 = verseRange(n(1), n(2), n(3), n(4), n(18));
  const range2 = range(verse(n(1), n(2), n(3), n(11)), verse(n(1), n(2), n(5), n(2)));
  const result1 = range(verse(n(1), n(2), n(3), n(4)), verse(n(1), n(2), n(5), n(2)));
  expect(mergeRanges([range1, range2])).toEqual([result1]);
});

test('combine adjacent verses', () => {
  const range1 = verseRange(n(1), n(2), n(3), n(4), n(6));
  const range2 = verseRange(n(1), n(2), n(3), n(7), n(8));
  const range3 = verseRange(n(1), n(2), n(3), n(4), n(8));
  expect(combineRanges([range2, range1])).toEqual([range3]);
});

test('combine adjacent verses complex', () => {
  const range1 = verseRange(n(1), n(2), n(3), n(4), n(6));
  const range2 = verseRange(n(1), n(2), n(3), n(9), n(12));
  const range3 = verseRange(n(1), n(2), n(3), n(11), n(15));
  const range4 = verseRange(n(1), n(2), n(3), n(2), n(5));
  const result1 = verseRange(n(1), n(2), n(3), n(2), n(6));
  const result2 = verseRange(n(1), n(2), n(3), n(9), n(15));
  expect(combineRanges([range1, range2, range3, range4])).toEqual([result1, result2]);
});

test('combine adjacent verses inter-chapter', () => {
  const range1 = range(verse(n(1), n(2), n(3), n(4)), verse(n(1), n(2), n(4), n(18)));
  const range2 = range(verse(n(1), n(2), n(4), n(11)), verse(n(1), n(2), n(5), n(2)));
  const result1 = range(verse(n(1), n(2), n(3), n(4)), verse(n(1), n(2), n(5), n(2)));
  expect(combineRanges([range1, range2])).toEqual([result1]);
});

test('combine adjacent chapters', () => {
  const range1 = chapterRange(n(1), n(2), n(3));
  const range2 = chapterRange(n(1), n(2), n(4), n(5));
  const combined = combineRanges([range2, range1]);
  expect(combined).toEqual([range(verse(n(1), n(2), n(3), n(1)), verse(n(1), n(2), n(5), n(999)))]);
});

test('combine adjacent books', () => {
  const range1 = bookRange(n(1), n(2), n(3));
  const range2 = bookRange(n(1), n(4), n(5));
  const combined = combineRanges([range2, range1]);
  expect(combined).toEqual([range(verse(n(1), n(2), n(1), n(1)), verse(n(1), n(5), n(999), n(999)))]);
});

test('isBookRange', () => {
  expect(bookRange(n(1), n(2), n(3)).isBookRange()).toBe(true);
});

test('isInterBookRange', () => {
  expect(range(verse(n(1), n(1), n(1), n(1)), verse(n(1), n(2), n(1), n(1))).isInterBookRange()).toBe(true);
});

test('isBook', () => {
  expect(bookRange(n(1), n(2)).isBook()).toBe(true);
});

test('isChapterRange', () => {
  expect(chapterRange(n(1), n(2), n(3), n(4)).isChapterRange()).toBe(true);
});

test('isInterChapterRange', () => {
  expect(range(verse(n(1), n(1), n(1), n(2)), verse(n(1), n(1), n(3), n(4))).isInterChapterRange()).toBe(true);
});

test('isChapter', () => {
  expect(chapterRange(n(1), n(2), n(3)).isChapter()).toBe(true);
});

test('isVerseRange', () => {
  expect(verseRange(n(1), n(2), n(3), n(4), n(5)).isVerseRange()).toBe(true);
});

test('isVerse', () => {
  expect(verseRange(n(1), n(2), n(3), n(4)).isVerse()).toBe(true);
});
