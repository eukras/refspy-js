import { makeNumber } from '../src/types/number';
import { Book } from '../src/models/book';
import { Library } from '../src/models/library';

export const FIRST_BOOK: Book = {
  id: makeNumber(1),
  name: 'Primo Booko',
  abbrev: 'Primo',
  aliases: [],
  chapters: 10,
};

export const BIG_BOOK: Book = {
  id: makeNumber(2),
  name: 'Big Book',
  abbrev: 'Big',
  aliases: ['Large', 'Bg'],
  chapters: 50,
};

export const SMALL_BOOK: Book = {
  id: makeNumber(3),
  name: 'Small Book',
  abbrev: 'Small',
  aliases: ['Tiny', 'Sm'],
  chapters: 1,
};

export const BOOK_1: Book = {
  id: makeNumber(4),
  name: '1 Book',
  abbrev: '1 Bk',
  aliases: [],
  chapters: 10,
};

export const BOOK_2: Book = {
  id: makeNumber(5),
  name: '2 Book',
  abbrev: '2 Bk',
  aliases: [],
  chapters: 5,
};

export const BOOK_3: Book = {
  id: makeNumber(6),
  name: '3 Book',
  abbrev: '3 Bk',
  aliases: [],
  chapters: 1,
};

export const LAST_BOOK: Book = {
  id: makeNumber(7),
  name: 'Last Book',
  abbrev: 'Last',
  aliases: ['Finale'],
  chapters: 10,
};

export const TEST_LIBRARY: Library = {
  id: makeNumber(1),
  name: 'Library',
  abbrev: 'Lib',
  books: [FIRST_BOOK, BIG_BOOK, SMALL_BOOK, BOOK_1, BOOK_2, BOOK_3, LAST_BOOK],
};

export const BOOK_4: Book = {
  id: makeNumber(1),
  name: '4 Book',
  abbrev: '4 Bk',
  aliases: [],
  chapters: 5,
};

export const TEST_LIBRARY_2: Library = {
  id: makeNumber(2),
  name: '2 Library',
  abbrev: '2 Lib',
  books: [BOOK_4],
};
