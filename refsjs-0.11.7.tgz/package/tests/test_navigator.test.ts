import { makeNumber } from '../src/types/number';
import { indexBookAliases, indexBooks } from '../src/indexers';
import { NT } from '../src/libraries/en_US';
import { Navigator } from '../src/navigator';
import { chapterReference } from '../src/models/reference';

const books = indexBooks([NT]);
const bookAliases = indexBookAliases([NT]);
const nav = new Navigator(books, bookAliases);
const ch = chapterReference;

test('prev chapter', () => {
  expect(nav.prevChapter(ch(NT.id, makeNumber(6), makeNumber(7)))).toEqual(ch(NT.id, makeNumber(6), makeNumber(6)));  // Rom 7 -> Rom 6
  expect(nav.prevChapter(ch(NT.id, makeNumber(6), makeNumber(1)))).toEqual(ch(NT.id, makeNumber(5), makeNumber(28))); // Rom 1 -> Acts 28
  expect(nav.prevChapter(ch(NT.id, makeNumber(1), makeNumber(1)))).toBeNull(); // Matt 1 -> None
});

test('next chapter', () => {
  expect(nav.nextChapter(ch(NT.id, makeNumber(6), makeNumber(7)))).toEqual(ch(NT.id, makeNumber(6), makeNumber(8)));  // Rom 7 -> Rom 8
  expect(nav.nextChapter(ch(NT.id, makeNumber(6), makeNumber(16)))).toEqual(ch(NT.id, makeNumber(7), makeNumber(1))); // Rom 16 -> 1 Cor 1
  expect(nav.nextChapter(ch(NT.id, makeNumber(27), makeNumber(22)))).toBeNull(); // Rev 22 -> None
});
