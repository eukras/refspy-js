import { makeNumber } from '../src/types/number';
import { refspy } from '../src/index';
import { NT } from '../src/libraries/fr_FR';
import { verseRange } from '../src/models/range';
import { reference, verseReference } from '../src/models/reference';

const n = makeNumber;
const frEuro = refspy('catholic', 'fr_FR', 'euro');
const frIntl = refspy('catholic', 'fr_FR', 'intl');

test('numbered books', () => {
  const I_COR_1_4 = verseReference(NT.id, n(7), n(1), n(4));
  const II_COR_1_4 = verseReference(NT.id, n(8), n(1), n(4));
  const II_COR_1_4_6 = reference(
    verseRange(NT.id, n(8), n(1), n(4)),
    verseRange(NT.id, n(8), n(1), n(6)),
  );
  const II_COR_1_4_67 = reference(
    verseRange(NT.id, n(8), n(1), n(4)),
    verseRange(NT.id, n(8), n(1), n(6), n(7)),
  );

  expect(frEuro.r('1 Co 1, 4')).toEqual(I_COR_1_4);
  expect(frEuro.r('2 Co 1, 4')).toEqual(II_COR_1_4);
  expect(frEuro.r('2 Co 1, 4.6')).toEqual(II_COR_1_4_6);

  expect(frEuro.r('1 Corinthiens 1, 4')).toEqual(I_COR_1_4);
  expect(frEuro.r('2 Corinthiens 1, 4')).toEqual(II_COR_1_4);

  expect(frEuro.r('Première Lettre à Co 1, 4')).toEqual(I_COR_1_4);
  expect(frEuro.r('Première Lettre à Corinthiens 1, 4')).toEqual(I_COR_1_4);
  expect(frEuro.r('Seconde Lettre à Co 1, 4')).toEqual(II_COR_1_4);
  expect(frEuro.r('Seconde Lettre à Corinthiens 1, 4')).toEqual(II_COR_1_4);

  expect(frEuro.r('1ere Co 1, 4')).toEqual(I_COR_1_4);
  expect(frEuro.r('1ere Corinthiens 1, 4')).toEqual(I_COR_1_4);
  expect(frEuro.r('2nd Co 1, 4')).toEqual(II_COR_1_4);
  expect(frEuro.r('2nd Corinthiens 1, 4')).toEqual(II_COR_1_4);

  expect(frEuro.r('I Co 1, 4')).toEqual(I_COR_1_4);
  expect(frEuro.r('I Corinthiens 1, 4')).toEqual(I_COR_1_4);
  expect(frEuro.r('II Co 1, 4')).toEqual(II_COR_1_4);
  expect(frEuro.r('II Corinthiens 1, 4')).toEqual(II_COR_1_4);

  expect(frIntl.r('2 Co 1:4,6')).toEqual(II_COR_1_4_6);
  expect(frEuro.r('2 Co 1,4.6')).toEqual(II_COR_1_4_6);

  expect(frIntl.r('2 Co 1:4,6-7')).toEqual(II_COR_1_4_67);
  expect(frEuro.r('2 Co 1,4.6-7')).toEqual(II_COR_1_4_67);
});

test('multiple references', () => {
  const refs = frEuro.findReferences('Rm 12,1.6-17, 2 Co. 1, 2–3,4, ou bien Philémon 2-3');
  expect(refs.length).toBe(3);
  expect(refs[0][1]).toEqual(frEuro.r('Rm 12,1.6-17'));
  expect(refs[1][1]).toEqual(frEuro.r('2 Co. 1, 2–3,4'));
  expect(refs[2][1]).toEqual(frEuro.r('Philémon 2-3'));
});
