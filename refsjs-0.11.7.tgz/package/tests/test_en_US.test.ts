import { makeNumber } from '../src/types/number';
import { refspy } from '../src/index';
import { DC, DC_ORTHODOX, NT } from '../src/libraries/en_US';
import { verseReference } from '../src/models/reference';

const n = makeNumber;
const __ = refspy();

test('numbered books', () => {
  const I_COR_1_4 = verseReference(NT.id, n(7), n(1), n(4));
  const II_COR_1_4 = verseReference(NT.id, n(8), n(1), n(4));

  expect(__.r('1 Cor 1:4')).toEqual(I_COR_1_4);
  expect(__.r('1 Corinthians 1:4')).toEqual(I_COR_1_4);
  expect(__.r('2 Cor 1:4')).toEqual(II_COR_1_4);
  expect(__.r('2 Corinthians 1:4')).toEqual(II_COR_1_4);

  expect(__.r('First Cor 1:4')).toEqual(I_COR_1_4);
  expect(__.r('First Corinthians 1:4')).toEqual(I_COR_1_4);
  expect(__.r('Second Cor 1:4')).toEqual(II_COR_1_4);
  expect(__.r('Second Corinthians 1:4')).toEqual(II_COR_1_4);

  expect(__.r('1st Cor 1:4')).toEqual(I_COR_1_4);
  expect(__.r('1st Corinthians 1:4')).toEqual(I_COR_1_4);
  expect(__.r('2nd Cor 1:4')).toEqual(II_COR_1_4);
  expect(__.r('2nd Corinthians 1:4')).toEqual(II_COR_1_4);

  expect(__.r('I Cor 1:4')).toEqual(I_COR_1_4);
  expect(__.r('I Corinthians 1:4')).toEqual(I_COR_1_4);
  expect(__.r('II Cor 1:4')).toEqual(II_COR_1_4);
  expect(__.r('II Corinthians 1:4')).toEqual(II_COR_1_4);
});

test('deuterocanonicals', () => {
  const catholic = refspy('catholic', 'en_US');
  const orthodox = refspy('orthodox', 'en_US');
  expect(catholic.r('2 Macc 1:1')).toEqual(verseReference(DC.id, n(14), n(1), n(1)));
  expect(catholic.r('3 Macc 1:1')).toBeNull();
  expect(orthodox.r('2 Macc 1:1')).toEqual(verseReference(DC.id, n(14), n(1), n(1)));
  expect(orthodox.r('3 Macc 1:1')).toEqual(verseReference(DC_ORTHODOX.id, n(4), n(1), n(1)));
});
