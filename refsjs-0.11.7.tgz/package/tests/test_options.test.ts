import { makeNumber } from '../src/types/number';
import { refspy } from '../src/index';

const n = makeNumber;

test('include two letter aliases', () => {
  const __ = refspy();  // includes two-letter aliases by default

  let [match, ref] = __.firstReference('1Ti 2');
  expect(match).toBe('1Ti 2');
  expect(ref).toEqual(__.bcv('1 Tim', n(2)));

  [match, ref] = __.firstReference('Ge 1:1');
  expect(match).toBe('Ge 1:1');
  expect(ref).toEqual(__.bcv('Gen', n(1), n(1)));

  [match, ref] = __.firstReference('Jn 1:1');
  expect(match).toBe('Jn 1:1');
  expect(ref).toEqual(__.bcv('John', n(1), n(1)));
});

test('exclude two letter aliases', () => {
  const __ = refspy('protestant', 'en_US', undefined, false);

  let [match, ref] = __.firstReference('1Ti 2');
  expect(match).toBeNull();
  expect(ref).toBeNull();

  [match, ref] = __.firstReference('Ob 2');
  expect(match).toBeNull();
  expect(ref).toBeNull();

  [match, ref] = __.firstReference('Am 1:1');
  expect(match).toBeNull();
  expect(ref).toBeNull();

  [match, ref] = __.firstReference('Is 1:1');
  expect(match).toBeNull();
  expect(ref).toBeNull();
});

test('skips ambiguous aliases for context references', () => {
  const __ = refspy();
  const refs = __.findReferences('Am. Am 3:1.');
  expect(refs.length).toBe(1);
  expect(refs[0][0]).toBe('Am 3:1');
  expect(refs[0][1]).toEqual(__.bcv('Amos', n(3), n(1)));
});
