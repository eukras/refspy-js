import { makeNumber } from '../src/types/number';
import { range } from '../src/models/range';
import {
  Reference,
  reference,
  chapterReference,
  verseReference,
} from '../src/models/reference';
import { verse } from '../src/models/verse';

const n = makeNumber;

test('empty reference raises error', () => {
  expect(() => reference()).toThrow();
});

test('less than', () => {
  const ch3v45 = verseReference(n(1), n(2), n(3), n(4), n(5));
  const ch3v47 = verseReference(n(1), n(2), n(3), n(4), n(7));
  const ch3v49 = verseReference(n(1), n(2), n(3), n(4), n(9));
  expect(ch3v45.add(ch3v47).lt(ch3v45.add(ch3v49))).toBe(true);
  expect(ch3v45.add(ch3v49).lt(ch3v45.add(ch3v47))).toBe(false);
});

test('minimum', () => {
  const reference1 = reference(range(verse(n(1), n(2), n(3), n(4)), verse(n(1), n(2), n(3), n(6))));
  const reference2 = reference(range(verse(n(1), n(2), n(3), n(7)), verse(n(1), n(2), n(3), n(8))));
  expect(reference1.lt(reference2)).toBe(true);
  const arr = [reference1, reference2];
  expect(arr.reduce((a, b) => (a.lt(b) ? a : b))).toEqual(reference1);
  expect(arr.reduce((a, b) => (a.lt(b) ? b : a))).toEqual(reference2);
});

test('sorting', () => {
  const ch3v45 = verseReference(n(1), n(2), n(3), n(4), n(5));
  const ch3v47 = verseReference(n(1), n(2), n(3), n(4), n(7));
  const ch3v49 = verseReference(n(1), n(2), n(3), n(4), n(9));
  const sorted = [ch3v49, ch3v47, ch3v45].sort((a, b) => (a.lt(b) ? -1 : b.lt(a) ? 1 : 0));
  expect(sorted).toEqual([ch3v45, ch3v47, ch3v49]);
});

test('reference addition', () => {
  const range1 = range(verse(n(1), n(2), n(3), n(4)), verse(n(1), n(2), n(3), n(6)));
  const range2 = range(verse(n(1), n(2), n(3), n(7)), verse(n(1), n(2), n(3), n(8)));
  const ref1 = reference(range1);
  const ref2 = reference(range2);
  const ref3 = reference(range1, range2);
  expect(ref1.add(ref2)).toEqual(ref3);
});

test('contains', () => {
  const ch3 = chapterReference(n(1), n(2), n(3));
  const ch3v45 = verseReference(n(1), n(2), n(3), n(4), n(5));
  expect(ch3.contains(ch3)).toBe(true);
  expect(ch3v45.contains(ch3v45)).toBe(true);
  expect(ch3.contains(ch3v45)).toBe(true);
  expect(ch3v45.contains(ch3)).toBe(false);
});

test('overlaps', () => {
  const ch3 = chapterReference(n(1), n(2), n(3));
  const ch3v45 = verseReference(n(1), n(2), n(3), n(4), n(5));
  expect(ch3.overlaps(ch3)).toBe(true);
  expect(ch3v45.overlaps(ch3v45)).toBe(true);
  expect(ch3.overlaps(ch3v45)).toBe(true);
  expect(ch3v45.overlaps(ch3)).toBe(true);
});

test('adjoins', () => {
  const ch3v45 = verseReference(n(1), n(2), n(3), n(4), n(5));
  const ch3v67 = verseReference(n(1), n(2), n(3), n(6), n(7));
  expect(ch3v45.adjoins(ch3v67)).toBe(true);
  expect(ch3v67.adjoins(ch3v45)).toBe(true);
});
