import { makeNumber } from '../src/types/number';
import { Formatter } from '../src/formatter';
import { indexBookAliases, indexBooks } from '../src/indexers';
import { ENGLISH } from '../src/languages/english';
import { range } from '../src/models/range';
import { reference } from '../src/models/reference';
import { verse } from '../src/models/verse';
import { TEST_LIBRARY, TEST_LIBRARY_2 } from './data';

const books = indexBooks([TEST_LIBRARY, TEST_LIBRARY_2]);
const bookAliases = indexBookAliases([TEST_LIBRARY, TEST_LIBRARY_2]);
const fmt = new Formatter(books, bookAliases);
const n = makeNumber;

test('book reference', () => {
  const ref = reference(range(verse(n(1), n(2), n(1), n(1)), verse(n(1), n(2), n(999), n(999))));
  expect(fmt.format(ref, fmt.nameFormat(ENGLISH))).toBe('Big Book');
});

test('book range', () => {
  const ref = reference(range(verse(n(1), n(2), n(1), n(1)), verse(n(1), n(3), n(999), n(999))));
  expect(fmt.format(ref, fmt.abbrevNameFormat(ENGLISH))).toBe('Big—Small');
});

test('chapter reference', () => {
  const ref = reference(range(verse(n(1), n(2), n(3), n(1)), verse(n(1), n(2), n(3), n(999))));
  expect(fmt.format(ref, fmt.nameFormat(ENGLISH))).toBe('Big Book 3');
});

test('chapter range', () => {
  const ref = reference(range(verse(n(1), n(2), n(3), n(1)), verse(n(1), n(2), n(4), n(999))));
  expect(fmt.format(ref, fmt.nameFormat(ENGLISH))).toBe('Big Book 3–4');
});

test('single range', () => {
  const ref = reference(range(verse(n(1), n(2), n(1), n(1)), verse(n(1), n(2), n(1), n(2))));
  expect(fmt.format(ref, fmt.nameFormat(ENGLISH))).toBe('Big Book 1:1–2');
  expect(fmt.format(ref, fmt.abbrevNameFormat(ENGLISH))).toBe('Big 1:1–2');
  expect(fmt.format(ref, fmt.numberFormat(ENGLISH))).toBe('1:1–2');
});

test('multiple verse range', () => {
  const ref = reference(
    range(verse(n(1), n(2), n(1), n(1)), verse(n(1), n(2), n(1), n(2))),
    range(verse(n(1), n(2), n(1), n(7)), verse(n(1), n(2), n(1), n(9))),
  );
  expect(fmt.format(ref, fmt.nameFormat(ENGLISH))).toBe('Big Book 1:1–2, 7–9');
});

test('inter-chapter ranges', () => {
  const ref = reference(
    range(verse(n(1), n(2), n(1), n(20)), verse(n(1), n(2), n(2), n(10))),
    range(verse(n(1), n(2), n(3), n(21)), verse(n(1), n(2), n(4), n(11))),
  );
  expect(fmt.format(ref, fmt.nameFormat(ENGLISH))).toBe('Big Book 1:20–2:10; 3:21–4:11');
});

test('multiple chapter range', () => {
  const ref = reference(
    range(verse(n(1), n(2), n(1), n(1)), verse(n(1), n(2), n(1), n(2))),
    range(verse(n(1), n(2), n(2), n(1)), verse(n(1), n(2), n(2), n(2))),
  );
  expect(fmt.format(ref, fmt.nameFormat(ENGLISH))).toBe('Big Book 1:1–2; 2:1–2');
});

test('inter-book range', () => {
  const ref = reference(range(verse(n(1), n(1), n(1), n(20)), verse(n(1), n(2), n(2), n(10))));
  expect(fmt.format(ref, fmt.nameFormat(ENGLISH))).toBe('Primo Booko 1:20 – Big Book 2:10');
});

test('multiple book range', () => {
  const ref = reference(
    range(verse(n(1), n(2), n(1), n(1)), verse(n(1), n(2), n(1), n(2))),
    range(verse(n(1), n(3), n(1), n(1)), verse(n(1), n(3), n(1), n(2))),
  );
  expect(fmt.format(ref, fmt.nameFormat(ENGLISH))).toBe('Big Book 1:1–2; Small Book 1–2');
});

test('multiple library range', () => {
  const ref = reference(
    range(verse(n(1), n(2), n(1), n(1)), verse(n(1), n(2), n(1), n(2))),
    range(verse(n(2), n(1), n(2), n(1)), verse(n(2), n(1), n(2), n(1))),
  );
  expect(fmt.format(ref, fmt.nameFormat(ENGLISH))).toBe('Big Book 1:1–2; 4 Book 2:1');
});

test('book chapters greater than 1', () => {
  const ref = reference(range(verse(n(1), n(2), n(1), n(1)), verse(n(1), n(2), n(1), n(2))));
  expect(fmt.format(ref, fmt.nameFormat(ENGLISH))).toBe('Big Book 1:1–2');
});

test('book chapter equal 1', () => {
  const ref = reference(range(verse(n(1), n(3), n(1), n(1)), verse(n(1), n(3), n(1), n(2))));
  expect(fmt.format(ref, fmt.nameFormat(ENGLISH))).toBe('Small Book 1–2');
});
