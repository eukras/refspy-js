import { refspy } from '../src/index';
import { ENGLISH } from '../src/languages/english';
import {
  addSpaceAfterBookNumber,
  getUnnumberedBookAliases,
  normalizeSpacing,
  parseNumber,
  sequentialReplace,
  sequentialReplaceTuples,
  stripBookNumber,
  stripSpaceAfterBookNumber,
  urlParam,
  urlEscape,
} from '../src/utils';

const __ = refspy();

test('parseNumber', () => {
  expect(parseNumber('USD $50')).toBe(50);
});

test('parseNumber raises on no number', () => {
  expect(() => parseNumber('My offer is this: nothing.')).toThrow();
});

test('urlParam', () => {
  expect(urlParam('1 Cor 3:4–5')).toBe('1+cor+3.4-5');
});

test('urlEscape', () => {
  expect(urlEscape('1 Cor 3:4–5')).toBe('1%20Cor%203%3A4-5');
});

test('stripBookNumber', () => {
  expect(stripBookNumber('2 Tim')).toBe('Tim');
  expect(stripBookNumber('2Tim')).toBe('2Tim');
  expect(stripBookNumber('1st')).toBe('1st');
});

test('stripSpaceAfterBookNumber', () => {
  expect(stripSpaceAfterBookNumber('2 Tim')).toBe('2Tim');
  expect(stripSpaceAfterBookNumber('2  Tim')).toBe('2 Tim');
  expect(stripSpaceAfterBookNumber('2Tim')).toBe('2Tim');
  expect(stripSpaceAfterBookNumber('1st')).toBe('1st');
});

test('addSpaceAfterBookNumber', () => {
  const unnumberedBookAliases = getUnnumberedBookAliases(__.bookAliases);
  const np = ENGLISH.numberPrefixes;

  expect(addSpaceAfterBookNumber('2Tim', unnumberedBookAliases, np)).toBe('2 Tim');
  expect(addSpaceAfterBookNumber('IITim', unnumberedBookAliases, np)).toBe('2 Tim');
  expect(addSpaceAfterBookNumber('2ndTim', unnumberedBookAliases, np)).toBe('2 Tim');
  expect(addSpaceAfterBookNumber('SecondTim', unnumberedBookAliases, np)).toBe('2 Tim');
  expect(addSpaceAfterBookNumber('2 Tim', unnumberedBookAliases, np)).toBe('2 Tim');
  expect(addSpaceAfterBookNumber('II Tim', unnumberedBookAliases, np)).toBe('II Tim');
  expect(addSpaceAfterBookNumber('2nd Tim', unnumberedBookAliases, np)).toBe('2nd Tim');
  expect(addSpaceAfterBookNumber('Second Tim', unnumberedBookAliases, np)).toBe('Second Tim');
});

test('normalizeSpacing', () => {
  expect(normalizeSpacing('  a  \t\t b    c  \n\r  d   e   ')).toBe(' a b c d e ');
});

test('sequentialReplaceTuples', () => {
  const text = '1 Cor 1; 1 Cor 1:1; 1 Cor 1:1-4';
  const tuples: [string, string][] = [
    ['1 Cor 1', 'XXXXXXX'],
    ['1 Cor 1:1', 'YYYYYYYYY'],
    ['1 Cor 1:1-4', 'ZZZZZZZZZZZ'],
  ];
  expect(sequentialReplaceTuples(text, tuples)).toBe('XXXXXXX; YYYYYYYYY; ZZZZZZZZZZZ');
});

test('sequentialReplace', () => {
  const text = '1 Cor 1; 1 Cor 1:1; 1 Cor 1:1-4';
  const strs = ['1 Cor 1', '1 Cor 1:1', '1 Cor 1:1-4'];
  const tags = ['XXXXXXX', 'YYYYYYYYY', 'ZZZZZZZZZZZ'];
  expect(sequentialReplace(text, strs, tags)).toBe('XXXXXXX; YYYYYYYYY; ZZZZZZZZZZZ');
});
