import { refspy } from '../src/index';
import { EUROPEAN } from '../src/syntax/european';
import { INTERNATIONAL } from '../src/syntax/international';

const fr = refspy('catholic', 'fr_FR');        // defaults to 'euro'
const frIntl = refspy('catholic', 'fr_FR', 'intl');

test('syntax setup', () => {
  expect(fr.matcher.syntax).toEqual(EUROPEAN);
  expect(frIntl.matcher.syntax).toEqual(INTERNATIONAL);
});

test('international syntax', () => {
  expect(frIntl.r('2 Co. 1:4')).toEqual(fr.r('2 Co 1,4'));
  expect(frIntl.r('2 Co 1:4-5')).toEqual(fr.r('2 Co 1,4-5'));
  expect(frIntl.r('2 Co 1:4,6')).toEqual(fr.r('2 Co 1,4.6'));
  expect(frIntl.r('2 Co 1:4,6-7')).toEqual(fr.r('2 Co 1,4.6-7'));
  expect(frIntl.r('Ro 12:1,1-27')).toEqual(fr.r('Ro 12,1.15-17'));
});
