import { makeNumber } from '../src/types/number';
import { Verse, verse } from '../src/models/verse';

test('shorthand', () => {
  const v = verse(makeNumber(1), makeNumber(2), makeNumber(3), makeNumber(4));
  expect(v.library).toBe(1);
  expect(v.book).toBe(2);
  expect(v.chapter).toBe(3);
  expect(v.verse).toBe(4);
});

test('fromIndex', () => {
  const v = Verse.fromIndex(1002003004);
  expect(v.library).toBe(1);
  expect(v.book).toBe(2);
  expect(v.chapter).toBe(3);
  expect(v.verse).toBe(4);
});

test('constructor', () => {
  const v = new Verse(makeNumber(1), makeNumber(2), makeNumber(3), makeNumber(4));
  expect(v.library).toBe(1);
  expect(v.book).toBe(2);
  expect(v.chapter).toBe(3);
  expect(v.verse).toBe(4);
});

test('args out of number range', () => {
  expect(() => verse(makeNumber(0 as never), makeNumber(2), makeNumber(3), makeNumber(4))).toThrow();
  expect(() => verse(makeNumber(1000 as never), makeNumber(2), makeNumber(3), makeNumber(4))).toThrow();
  expect(() => makeNumber(0)).toThrow();
  expect(() => makeNumber(1000)).toThrow();
  expect(() => verse(makeNumber(1), makeNumber(0 as never), makeNumber(3), makeNumber(4))).toThrow();
  expect(() => verse(makeNumber(1), makeNumber(1000 as never), makeNumber(3), makeNumber(4))).toThrow();
  expect(() => verse(makeNumber(1), makeNumber(2), makeNumber(0 as never), makeNumber(4))).toThrow();
  expect(() => verse(makeNumber(1), makeNumber(2), makeNumber(1000 as never), makeNumber(4))).toThrow();
  expect(() => verse(makeNumber(1), makeNumber(2), makeNumber(3), makeNumber(0 as never))).toThrow();
  expect(() => verse(makeNumber(1), makeNumber(2), makeNumber(3), makeNumber(1000 as never))).toThrow();
});

test('tuples', () => {
  const v = verse(makeNumber(1), makeNumber(2), makeNumber(3), makeNumber(4));
  expect(v.toTuple()).toEqual([1, 2, 3, 4]);
});

test('index numbers', () => {
  const v = verse(makeNumber(1), makeNumber(2), makeNumber(3), makeNumber(4));
  expect(v.index()).toBe(1002003004);
});
